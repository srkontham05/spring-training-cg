package com.srini;

public interface MyInterFace 
{
	void m1();
}
