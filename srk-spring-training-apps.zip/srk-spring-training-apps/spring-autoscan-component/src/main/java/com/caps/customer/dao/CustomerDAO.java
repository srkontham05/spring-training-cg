package com.caps.customer.dao;

import org.springframework.stereotype.Repository;

@Repository
public class CustomerDAO 
{
	@Override
	public String toString() {
		return "Hello , This is CustomerDAO";
	}	
}
