package com.srk.tutorial.spring.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RootConfig {
	//..
}
