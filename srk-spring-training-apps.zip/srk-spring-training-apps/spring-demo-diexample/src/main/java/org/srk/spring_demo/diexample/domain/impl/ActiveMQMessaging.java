package org.srk.spring_demo.diexample.domain.impl;

import org.srk.spring_demo.diexample.domain.Messaging;

public class ActiveMQMessaging implements Messaging {

	public void sendMessage() {
		System.out.println("Active MQ Message");
	}
	
}
