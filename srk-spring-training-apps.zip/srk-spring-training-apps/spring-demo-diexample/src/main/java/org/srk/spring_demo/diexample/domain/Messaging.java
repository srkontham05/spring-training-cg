package org.srk.spring_demo.diexample.domain;

public interface Messaging {
	public void sendMessage();
}
