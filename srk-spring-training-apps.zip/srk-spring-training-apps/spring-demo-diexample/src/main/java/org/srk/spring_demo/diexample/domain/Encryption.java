package org.srk.spring_demo.diexample.domain;

public interface Encryption {
	public void encryptData();
}
