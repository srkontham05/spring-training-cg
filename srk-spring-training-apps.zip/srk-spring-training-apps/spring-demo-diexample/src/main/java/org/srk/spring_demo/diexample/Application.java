package org.srk.spring_demo.diexample;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Application {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("app-config.xml");
		
		Communication comm = (Communication) context.getBean("communication");
		comm.communicate();
	}
}
