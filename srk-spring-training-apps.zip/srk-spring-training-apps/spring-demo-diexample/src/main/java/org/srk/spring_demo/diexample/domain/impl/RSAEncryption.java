package org.srk.spring_demo.diexample.domain.impl;

import org.srk.spring_demo.diexample.domain.Encryption;

public class RSAEncryption implements Encryption	 {

	public void encryptData() {
		System.out.println("Encrypting data using RSA Encryptin");
	}
	
}
