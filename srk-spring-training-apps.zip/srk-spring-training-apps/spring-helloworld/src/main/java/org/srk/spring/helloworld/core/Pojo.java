package org.srk.spring.helloworld.core;

public class Pojo {
	private String name;
	private int mobileno;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMobile() {
		return mobileno;
	}

	public void setMobile(int mobile) {
		this.mobileno = mobile;
	}

}
