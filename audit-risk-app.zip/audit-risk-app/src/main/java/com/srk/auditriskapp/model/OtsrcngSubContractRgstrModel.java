package com.srk.auditriskapp.model;

public class OtsrcngSubContractRgstrModel {

    Integer orKey;
    String orId;
    String orNm;
    String mas634Flg;
    String materialChgFlg;
    String serviceName;

    public Integer getOrKey() {
        return orKey;
    }

    public void setOrKey(Integer orKey) {
        this.orKey = orKey;
    }

    public String getOrId() {
        return orId;
    }

    public void setOrId(String orId) {
        this.orId = orId;
    }

    public String getOrNm() {
        return orNm;
    }

    public void setOrNm(String orNm) {
        this.orNm = orNm;
    }

    public String getMas634Flg() {
        return mas634Flg;
    }

    public void setMas634Flg(String mas634Flg) {
        this.mas634Flg = mas634Flg;
    }

    public String getMaterialChgFlg() {
        return materialChgFlg;
    }

    public void setMaterialChgFlg(String materialChgFlg) {
        this.materialChgFlg = materialChgFlg;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
}
