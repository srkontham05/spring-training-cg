package com.srk.auditriskapp.model;

import java.util.List;

public class OtsrcngRgstrModel {
    
    Integer orKey;
    String orId;
    String orNm;
    String mas634Flg;
    String materialChgFlg;
    String serviceName;
    Integer aeNum;
    String aeName;
    Integer entity;
    Integer unit;
    List<OtsrcngSubContractRgstrModel> subContractDetails;

    public Integer getOrKey() {
        return orKey;
    }

    public void setOrKey(Integer orKey) {
        this.orKey = orKey;
    }

    public String getOrId() {
        return orId;
    }

    public void setOrId(String orId) {
        this.orId = orId;
    }

    public String getOrNm() {
        return orNm;
    }

    public void setOrNm(String orNm) {
        this.orNm = orNm;
    }

    public String getMas634Flg() {
        return mas634Flg;
    }

    public void setMas634Flg(String mas634Flg) {
        this.mas634Flg = mas634Flg;
    }

    public String getMaterialChgFlg() {
        return materialChgFlg;
    }

    public void setMaterialChgFlg(String materialChgFlg) {
        this.materialChgFlg = materialChgFlg;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public Integer getAeNum() {
        return aeNum;
    }

    public void setAeNum(Integer aeNum) {
        this.aeNum = aeNum;
    }

    public String getAeName() {
        return aeName;
    }

    public void setAeName(String aeName) {
        this.aeName = aeName;
    }

    public List<OtsrcngSubContractRgstrModel> getSubContractDetails() {
        return subContractDetails;
    }

    public Integer getEntity() {
        return entity;
    }

    public void setEntity(Integer entity) {
        this.entity = entity;
    }

    public Integer getUnit() {
        return unit;
    }

    public void setUnit(Integer unit) {
        this.unit = unit;
    }

    public void setSubContractDetails(List<OtsrcngSubContractRgstrModel> subContractDetails) {
        this.subContractDetails = subContractDetails;
    }
}
