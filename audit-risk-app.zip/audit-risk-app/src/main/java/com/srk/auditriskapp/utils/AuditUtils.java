package com.srk.auditriskapp.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.srk.auditriskapp.model.BUEntityModel;
import com.srk.auditriskapp.model.OtsrcngRgstrModel;
import com.srk.auditriskapp.model.OtsrcngSubContractRgstrModel;
import com.srk.auditriskapp.repository.IAuditableEntityRepository;
import com.srk.auditriskapp.repository.IOtsrcngRgstrRepository;
import org.apache.commons.collections.CollectionUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.*;
import java.util.logging.Logger;

public class AuditUtils {

    private static final Logger LOGGER = Logger.getLogger(AuditUtils.class.getName());
    private static final ObjectMapper OBJ_MAPPER = new ObjectMapper();

    public static Map<Integer, String> getRequiredValuesFromJson(String jsonString, String requiredValue)
            throws org.json.simple.parser.ParseException {
        LOGGER.finer("Inside getRequiredValuesFromJson()");
        JSONParser parser = new JSONParser();
        JSONObject jsonObj = (JSONObject) parser.parse(jsonString);
        Iterator<?> jsonIterator = jsonObj.keySet().iterator();
        Map<Integer, String> indexMapper = new HashMap<>();
        while (jsonIterator.hasNext()) {
            String key = (String) jsonIterator.next();
            Long index = (Long) ((JSONObject) jsonObj.get(key)).get("index");
            indexMapper.put(index.intValue(), String.valueOf(((JSONObject) jsonObj.get(key)).get(requiredValue)));
        }
        LOGGER.finer("Prepared response");
        return indexMapper;
    }

    public static String convertObjToJSON(Object obj) {
        LOGGER.finer("Inside convertObjToJSON()");
        String value = null;
        try {
            value = OBJ_MAPPER.writeValueAsString(obj);
        } catch (JsonProcessingException exception) {
            LOGGER.finer("JsonProcessingException Cause" + exception.getCause());
            LOGGER.finer("JsonProcessingException" + exception);
        }
        LOGGER.finer("Prepared response : " + value);
        return value;
    }

    // Mapping Main OSPs and Sub-Contracts by BU Entity or Manual OSP Tag or AENum
    public static List<OtsrcngRgstrModel> mapMainOSPWithSubContracts(List<Object[]> fetchedMainOSPs, BUEntityModel currentUE,
                                                                     Integer aeNum, IOtsrcngRgstrRepository ospRepo, IAuditableEntityRepository aeRepo) {
        LOGGER.finer("Inside mapMainOSPWithSubContracts()");
        List<OtsrcngRgstrModel> sOtsrcngRgstr = new ArrayList<>();
        fetchedMainOSPs.forEach(currentOSP -> {
            OtsrcngRgstrModel otsrcngRgstr = new OtsrcngRgstrModel();
            otsrcngRgstr.setOrKey((Integer) currentOSP[0]);
            otsrcngRgstr.setOrId((String) currentOSP[1]);
            otsrcngRgstr.setOrNm((String) currentOSP[2]);
            otsrcngRgstr.setMas634Flg((String) currentOSP[3]);
            otsrcngRgstr.setMaterialChgFlg((String) currentOSP[4]);
            otsrcngRgstr.setServiceName((String) currentOSP[5]);

            if (aeNum != null && aeNum != 0) {
                otsrcngRgstr.setAeName(aeRepo.getAeName(aeNum));
                otsrcngRgstr.setAeNum(aeNum);
            }
            if (currentUE != null) {
                otsrcngRgstr.setEntity(currentUE.getEntityNum());
                otsrcngRgstr.setUnit(currentUE.getBuNum());
            }

            List<Integer> orKeysSubContracts = ospRepo.getORKeysSubContractForMainContract((Integer) currentOSP[0]);
            List<OtsrcngSubContractRgstrModel> sOtsrcngSubRgstr = new ArrayList<>();
            if (CollectionUtils.isNotEmpty(orKeysSubContracts)) {
                List<Object[]> fetchedSubContracts = ospRepo.fetchOSPforSubContract(orKeysSubContracts);
                if (CollectionUtils.isNotEmpty(fetchedSubContracts)) {
                    fetchedSubContracts.forEach(currentSubOSP -> {
                        OtsrcngSubContractRgstrModel otsrcngSubRgstr = new OtsrcngSubContractRgstrModel();
                        otsrcngSubRgstr.setOrKey((Integer) currentSubOSP[0]);
                        otsrcngSubRgstr.setOrId((String) currentSubOSP[1]);
                        otsrcngSubRgstr.setOrNm((String) currentSubOSP[2]);
                        otsrcngSubRgstr.setMas634Flg((String) currentSubOSP[3]);
                        otsrcngSubRgstr.setMaterialChgFlg((String) currentSubOSP[4]);
                        otsrcngSubRgstr.setServiceName((String) currentSubOSP[5]);
                        sOtsrcngSubRgstr.add(otsrcngSubRgstr);
                    });
                }
            }
            otsrcngRgstr.setSubContractDetails(sOtsrcngSubRgstr);
            sOtsrcngRgstr.add(otsrcngRgstr);
        });
        LOGGER.finer("Prepared response");
        return sOtsrcngRgstr;
    }

}
