package com.srk.auditriskapp.repository;

public interface IAuditableEntityRepository {

    public String getAeName(Integer aeNum);
}
