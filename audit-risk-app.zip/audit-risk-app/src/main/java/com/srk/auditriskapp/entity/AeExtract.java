package com.srk.auditriskapp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the ae_extract database table.
 */
@Entity
@Table(name = "ae_extract")
public class AeExtract implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "AE_AVG_SCR")
    private BigDecimal aeAvgScr;

    @Column(name = "AE_ID")
    private String aeId;

    @Column(name = "AE_NM")
    private String aeNm;

    @Id
    @Column(name = "AE_NUM")
    private int aeNum;

    @Column(name = "AE_RISK_CLR")
    private String aeRiskClr;

    @Column(name = "AE_RISK_RTNG")
    private String aeRiskRtng;


    @Column(name = "ASSMT_DT")
    private Date assmtDt;


    @Column(name = "BU_NM")
    private String buNm;

    @Column(name = "FUN_BU_NM")
    private String funcNm;

    private BigDecimal business_Strategic;

    private BigDecimal change_Management;

    @Column(name = "CNTRY_NM")
    private String cntryNm;

    private BigDecimal conduct;

    private BigDecimal credit;

    @Column(name = "ENTITY_NM")
    private String entityNm;

    private String fah;

    private BigDecimal financial_Control;

    private BigDecimal financial_Crime;

    private String newEntity;

    private String previousAes;

    private String previousCntrlRtng;

    private String rmrks;
    private String justification_Business_Strategic;


    private String justification_Change_Management;


    private String justification_Conduct;


    private String justification_Credit;


    private String justification_Financial_Control;


    private String justification_Financial_Crime;


    private String justification_Legal;


    private String justification_Liquidity;


    private String justification_Market;


    private String justification_People;


    private String justification_Process_Risk;


    private String justification_Reputational;


    private String justification_Security_Risk;


    private String justification_Sourcing;


    private String justification_Technology;


    @Column(name = "LAST_AUDIT_DT")
    private Date lastAuditDt;

    private BigDecimal legal;

    private BigDecimal liquidity;

    private String man;

    private BigDecimal market;

    private String mgmtOvrlyClr;

    private String mgmtOvrlyJstfn;

    private String mgmtOvrlyRtng;

    private BigDecimal mgmtOvrlyScr;

    private String net_Rtng_Business_Strategic;

    private String net_Rtng_Change_Management;

    private String net_Rtng_Conduct;

    private String net_Rtng_Credit;

    private String net_Rtng_Financial_Control;

    private String net_Rtng_Financial_Crime;

    private String net_Rtng_Legal;

    private String net_Rtng_Liquidity;

    private String net_Rtng_Market;

    private String net_Rtng_People;

    private String net_Rtng_Process_Risk;

    private String net_Rtng_Reputational;

    private String net_Rtng_Security_Risk;

    private String net_Rtng_Sourcing;

    private String net_Rtng_Technology;

    private BigDecimal people;


    @Column(name = "PRIMARY_BU_NM")
    private String primaryBuNm;

    private BigDecimal process_Risk;

    private BigDecimal reputational;

    private String rtng_Business_Strategic;

    private String rtng_Change_Management;

    private String rtng_Clr_Business_Strategic;

    private String rtng_Clr_Change_Management;

    private String rtng_Clr_Conduct;

    private String rtng_Clr_Credit;

    private String rtng_Clr_Financial_Control;

    private String rtng_Clr_Financial_Crime;

    private String rtng_Clr_Legal;

    private String rtng_Clr_Liquidity;

    private String rtng_Clr_Market;

    private String rtng_Clr_People;

    private String rtng_Clr_Process_Risk;

    private String rtng_Clr_Reputational;

    private String rtng_Clr_Security_Risk;

    private String rtng_Clr_Sourcing;

    private String rtng_Clr_Technology;

    private String rtng_Conduct;

    private String rtng_Credit;

    private String rtng_Financial_Control;

    private String rtng_Financial_Crime;

    private String rtng_Legal;

    private String rtng_Liquidity;

    private String rtng_Market;

    private String rtng_People;

    private String rtng_Process_Risk;

    private String rtng_Reputational;

    private BigDecimal rtng_Scr_Business_Strategic;

    private BigDecimal rtng_Scr_Change_Management;

    private BigDecimal rtng_Scr_Conduct;

    private BigDecimal rtng_Scr_Credit;

    private BigDecimal rtng_Scr_Financial_Control;

    private BigDecimal rtng_Scr_Financial_Crime;

    private BigDecimal rtng_Scr_Legal;

    private BigDecimal rtng_Scr_Liquidity;

    private BigDecimal rtng_Scr_Market;

    private BigDecimal rtng_Scr_People;

    private BigDecimal rtng_Scr_Process_Risk;

    private BigDecimal rtng_Scr_Reputational;

    private BigDecimal rtng_Scr_Security_Risk;

    private BigDecimal rtng_Scr_Sourcing;

    private BigDecimal rtng_Scr_Technology;

    private String rtng_Security_Risk;

    private String rtng_Sourcing;

    private String rtng_Technology;

    private BigDecimal security_Risk;

    private String sev_Rtng_Business_Strategic;

    private String sev_Rtng_Change_Management;

    private String sev_Rtng_Conduct;

    private String sev_Rtng_Credit;

    private String sev_Rtng_Financial_Control;

    private String sev_Rtng_Financial_Crime;

    private String sev_Rtng_Legal;

    private String sev_Rtng_Liquidity;

    private String sev_Rtng_Market;

    private String sev_Rtng_People;

    private String sev_Rtng_Process_Risk;

    private String sev_Rtng_Reputational;

    private String sev_Rtng_Security_Risk;

    private String sev_Rtng_Sourcing;

    private String sev_Rtng_Technology;

    private BigDecimal sourcing;

    @Column(name = "STATUS_CD_DESC")
    private String statusCdDesc;

    private BigDecimal technology;


    @Column(name = "UPDATE_DT_TM")
    private Date updateDtTm;


    @Column(name = "VENDOR_NM")
    private String vendorNm;

    public AeExtract() {
    }

    public BigDecimal getAeAvgScr() {
        return this.aeAvgScr;
    }

    public void setAeAvgScr(BigDecimal aeAvgScr) {
        this.aeAvgScr = aeAvgScr;
    }

    public String getAeId() {
        return this.aeId;
    }

    public void setAeId(String aeId) {
        this.aeId = aeId;
    }

    public String getAeNm() {
        return this.aeNm;
    }

    public void setAeNm(String aeNm) {
        this.aeNm = aeNm;
    }

    public int getAeNum() {
        return this.aeNum;
    }

    public void setAeNum(int aeNum) {
        this.aeNum = aeNum;
    }

    public String getAeRiskClr() {
        return this.aeRiskClr;
    }

    public void setAeRiskClr(String aeRiskClr) {
        this.aeRiskClr = aeRiskClr;
    }

    public String getAeRiskRtng() {
        return this.aeRiskRtng;
    }

    public void setAeRiskRtng(String aeRiskRtng) {
        this.aeRiskRtng = aeRiskRtng;
    }

    public Date getAssmtDt() {
        return this.assmtDt;
    }

    public void setAssmtDt(Date assmtDt) {
        this.assmtDt = assmtDt;
    }

    public String getBuNm() {
        return this.buNm;
    }

    public void setBuNm(String buNm) {
        this.buNm = buNm;
    }

    public BigDecimal getBusiness_Strategic() {
        return this.business_Strategic;
    }

    public void setBusiness_Strategic(BigDecimal business_Strategic) {
        this.business_Strategic = business_Strategic;
    }

    public BigDecimal getChange_Management() {
        return this.change_Management;
    }

    public void setChange_Management(BigDecimal change_Management) {
        this.change_Management = change_Management;
    }

    public String getCntryNm() {
        return this.cntryNm;
    }

    public void setCntryNm(String cntryNm) {
        this.cntryNm = cntryNm;
    }

    public BigDecimal getConduct() {
        return this.conduct;
    }

    public void setConduct(BigDecimal conduct) {
        this.conduct = conduct;
    }

    public BigDecimal getCredit() {
        return this.credit;
    }

    public void setCredit(BigDecimal credit) {
        this.credit = credit;
    }

    public String getEntityNm() {
        return this.entityNm;
    }

    public void setEntityNm(String entityNm) {
        this.entityNm = entityNm;
    }

    public String getFah() {
        return this.fah;
    }

    public void setFah(String fah) {
        this.fah = fah;
    }

    public BigDecimal getFinancial_Control() {
        return this.financial_Control;
    }

    public void setFinancial_Control(BigDecimal financial_Control) {
        this.financial_Control = financial_Control;
    }

    public BigDecimal getFinancial_Crime() {
        return this.financial_Crime;
    }

    public void setFinancial_Crime(BigDecimal financial_Crime) {
        this.financial_Crime = financial_Crime;
    }

    public String getJustification_Business_Strategic() {
        return this.justification_Business_Strategic;
    }

    public void setJustification_Business_Strategic(String justification_Business_Strategic) {
        this.justification_Business_Strategic = justification_Business_Strategic;
    }

    public String getJustification_Change_Management() {
        return this.justification_Change_Management;
    }

    public void setJustification_Change_Management(String justification_Change_Management) {
        this.justification_Change_Management = justification_Change_Management;
    }

    public String getJustification_Conduct() {
        return this.justification_Conduct;
    }

    public void setJustification_Conduct(String justification_Conduct) {
        this.justification_Conduct = justification_Conduct;
    }

    public String getJustification_Credit() {
        return this.justification_Credit;
    }

    public void setJustification_Credit(String justification_Credit) {
        this.justification_Credit = justification_Credit;
    }

    public String getJustification_Financial_Control() {
        return this.justification_Financial_Control;
    }

    public void setJustification_Financial_Control(String justification_Financial_Control) {
        this.justification_Financial_Control = justification_Financial_Control;
    }

    public String getJustification_Financial_Crime() {
        return this.justification_Financial_Crime;
    }

    public void setJustification_Financial_Crime(String justification_Financial_Crime) {
        this.justification_Financial_Crime = justification_Financial_Crime;
    }

    public String getJustification_Legal() {
        return this.justification_Legal;
    }

    public void setJustification_Legal(String justification_Legal) {
        this.justification_Legal = justification_Legal;
    }

    public String getJustification_Liquidity() {
        return this.justification_Liquidity;
    }

    public void setJustification_Liquidity(String justification_Liquidity) {
        this.justification_Liquidity = justification_Liquidity;
    }

    public String getJustification_Market() {
        return this.justification_Market;
    }

    public void setJustification_Market(String justification_Market) {
        this.justification_Market = justification_Market;
    }

    public String getJustification_People() {
        return this.justification_People;
    }

    public void setJustification_People(String justification_People) {
        this.justification_People = justification_People;
    }

    public String getJustification_Process_Risk() {
        return this.justification_Process_Risk;
    }

    public void setJustification_Process_Risk(String justification_Process_Risk) {
        this.justification_Process_Risk = justification_Process_Risk;
    }

    public String getJustification_Reputational() {
        return this.justification_Reputational;
    }

    public void setJustification_Reputational(String justification_Reputational) {
        this.justification_Reputational = justification_Reputational;
    }

    public String getJustification_Security_Risk() {
        return this.justification_Security_Risk;
    }

    public void setJustification_Security_Risk(String justification_Security_Risk) {
        this.justification_Security_Risk = justification_Security_Risk;
    }

    public String getJustification_Sourcing() {
        return this.justification_Sourcing;
    }

    public void setJustification_Sourcing(String justification_Sourcing) {
        this.justification_Sourcing = justification_Sourcing;
    }

    public String getJustification_Technology() {
        return this.justification_Technology;
    }

    public void setJustification_Technology(String justification_Technology) {
        this.justification_Technology = justification_Technology;
    }

    public Date getLastAuditDt() {
        return this.lastAuditDt;
    }

    public void setLastAuditDt(Date lastAuditDt) {
        this.lastAuditDt = lastAuditDt;
    }

    public BigDecimal getLegal() {
        return this.legal;
    }

    public void setLegal(BigDecimal legal) {
        this.legal = legal;
    }

    public BigDecimal getLiquidity() {
        return this.liquidity;
    }

    public void setLiquidity(BigDecimal liquidity) {
        this.liquidity = liquidity;
    }

    public String getMan() {
        return this.man;
    }

    public void setMan(String man) {
        this.man = man;
    }

    public BigDecimal getMarket() {
        return this.market;
    }

    public void setMarket(BigDecimal market) {
        this.market = market;
    }

    public String getMgmtOvrlyClr() {
        return this.mgmtOvrlyClr;
    }

    public void setMgmtOvrlyClr(String mgmtOvrlyClr) {
        this.mgmtOvrlyClr = mgmtOvrlyClr;
    }

    public String getMgmtOvrlyJstfn() {
        return this.mgmtOvrlyJstfn;
    }

    public void setMgmtOvrlyJstfn(String mgmtOvrlyJstfn) {
        this.mgmtOvrlyJstfn = mgmtOvrlyJstfn;
    }

    public String getMgmtOvrlyRtng() {
        return this.mgmtOvrlyRtng;
    }

    public void setMgmtOvrlyRtng(String mgmtOvrlyRtng) {
        this.mgmtOvrlyRtng = mgmtOvrlyRtng;
    }

    public BigDecimal getMgmtOvrlyScr() {
        return this.mgmtOvrlyScr;
    }

    public void setMgmtOvrlyScr(BigDecimal mgmtOvrlyScr) {
        this.mgmtOvrlyScr = mgmtOvrlyScr;
    }

    public String getNet_Rtng_Business_Strategic() {
        return this.net_Rtng_Business_Strategic;
    }

    public void setNet_Rtng_Business_Strategic(String net_Rtng_Business_Strategic) {
        this.net_Rtng_Business_Strategic = net_Rtng_Business_Strategic;
    }

    public String getNet_Rtng_Change_Management() {
        return this.net_Rtng_Change_Management;
    }

    public void setNet_Rtng_Change_Management(String net_Rtng_Change_Management) {
        this.net_Rtng_Change_Management = net_Rtng_Change_Management;
    }

    public String getNet_Rtng_Conduct() {
        return this.net_Rtng_Conduct;
    }

    public void setNet_Rtng_Conduct(String net_Rtng_Conduct) {
        this.net_Rtng_Conduct = net_Rtng_Conduct;
    }

    public String getNet_Rtng_Credit() {
        return this.net_Rtng_Credit;
    }

    public void setNet_Rtng_Credit(String net_Rtng_Credit) {
        this.net_Rtng_Credit = net_Rtng_Credit;
    }

    public String getNet_Rtng_Financial_Control() {
        return this.net_Rtng_Financial_Control;
    }

    public void setNet_Rtng_Financial_Control(String net_Rtng_Financial_Control) {
        this.net_Rtng_Financial_Control = net_Rtng_Financial_Control;
    }

    public String getNet_Rtng_Financial_Crime() {
        return this.net_Rtng_Financial_Crime;
    }

    public void setNet_Rtng_Financial_Crime(String net_Rtng_Financial_Crime) {
        this.net_Rtng_Financial_Crime = net_Rtng_Financial_Crime;
    }

    public String getNet_Rtng_Legal() {
        return this.net_Rtng_Legal;
    }

    public void setNet_Rtng_Legal(String net_Rtng_Legal) {
        this.net_Rtng_Legal = net_Rtng_Legal;
    }

    public String getNet_Rtng_Liquidity() {
        return this.net_Rtng_Liquidity;
    }

    public void setNet_Rtng_Liquidity(String net_Rtng_Liquidity) {
        this.net_Rtng_Liquidity = net_Rtng_Liquidity;
    }

    public String getNet_Rtng_Market() {
        return this.net_Rtng_Market;
    }

    public void setNet_Rtng_Market(String net_Rtng_Market) {
        this.net_Rtng_Market = net_Rtng_Market;
    }

    public String getNet_Rtng_People() {
        return this.net_Rtng_People;
    }

    public void setNet_Rtng_People(String net_Rtng_People) {
        this.net_Rtng_People = net_Rtng_People;
    }

    public String getNet_Rtng_Process_Risk() {
        return this.net_Rtng_Process_Risk;
    }

    public void setNet_Rtng_Process_Risk(String net_Rtng_Process_Risk) {
        this.net_Rtng_Process_Risk = net_Rtng_Process_Risk;
    }

    public String getNet_Rtng_Reputational() {
        return this.net_Rtng_Reputational;
    }

    public void setNet_Rtng_Reputational(String net_Rtng_Reputational) {
        this.net_Rtng_Reputational = net_Rtng_Reputational;
    }

    public String getNet_Rtng_Security_Risk() {
        return this.net_Rtng_Security_Risk;
    }

    public void setNet_Rtng_Security_Risk(String net_Rtng_Security_Risk) {
        this.net_Rtng_Security_Risk = net_Rtng_Security_Risk;
    }

    public String getNet_Rtng_Sourcing() {
        return this.net_Rtng_Sourcing;
    }

    public void setNet_Rtng_Sourcing(String net_Rtng_Sourcing) {
        this.net_Rtng_Sourcing = net_Rtng_Sourcing;
    }

    public String getNet_Rtng_Technology() {
        return this.net_Rtng_Technology;
    }

    public void setNet_Rtng_Technology(String net_Rtng_Technology) {
        this.net_Rtng_Technology = net_Rtng_Technology;
    }

    public BigDecimal getPeople() {
        return this.people;
    }

    public void setPeople(BigDecimal people) {
        this.people = people;
    }

    public String getPrimaryBuNm() {
        return this.primaryBuNm;
    }

    public void setPrimaryBuNm(String primaryBuNm) {
        this.primaryBuNm = primaryBuNm;
    }

    public BigDecimal getProcess_Risk() {
        return this.process_Risk;
    }

    public void setProcess_Risk(BigDecimal process_Risk) {
        this.process_Risk = process_Risk;
    }

    public BigDecimal getReputational() {
        return this.reputational;
    }

    public void setReputational(BigDecimal reputational) {
        this.reputational = reputational;
    }

    public String getRtng_Business_Strategic() {
        return this.rtng_Business_Strategic;
    }

    public void setRtng_Business_Strategic(String rtng_Business_Strategic) {
        this.rtng_Business_Strategic = rtng_Business_Strategic;
    }

    public String getRtng_Change_Management() {
        return this.rtng_Change_Management;
    }

    public void setRtng_Change_Management(String rtng_Change_Management) {
        this.rtng_Change_Management = rtng_Change_Management;
    }

    public String getRtng_Clr_Business_Strategic() {
        return this.rtng_Clr_Business_Strategic;
    }

    public void setRtng_Clr_Business_Strategic(String rtng_Clr_Business_Strategic) {
        this.rtng_Clr_Business_Strategic = rtng_Clr_Business_Strategic;
    }

    public String getRtng_Clr_Change_Management() {
        return this.rtng_Clr_Change_Management;
    }

    public void setRtng_Clr_Change_Management(String rtng_Clr_Change_Management) {
        this.rtng_Clr_Change_Management = rtng_Clr_Change_Management;
    }

    public String getRtng_Clr_Conduct() {
        return this.rtng_Clr_Conduct;
    }

    public void setRtng_Clr_Conduct(String rtng_Clr_Conduct) {
        this.rtng_Clr_Conduct = rtng_Clr_Conduct;
    }

    public String getRtng_Clr_Credit() {
        return this.rtng_Clr_Credit;
    }

    public void setRtng_Clr_Credit(String rtng_Clr_Credit) {
        this.rtng_Clr_Credit = rtng_Clr_Credit;
    }

    public String getRtng_Clr_Financial_Control() {
        return this.rtng_Clr_Financial_Control;
    }

    public void setRtng_Clr_Financial_Control(String rtng_Clr_Financial_Control) {
        this.rtng_Clr_Financial_Control = rtng_Clr_Financial_Control;
    }

    public String getRtng_Clr_Financial_Crime() {
        return this.rtng_Clr_Financial_Crime;
    }

    public void setRtng_Clr_Financial_Crime(String rtng_Clr_Financial_Crime) {
        this.rtng_Clr_Financial_Crime = rtng_Clr_Financial_Crime;
    }

    public String getRtng_Clr_Legal() {
        return this.rtng_Clr_Legal;
    }

    public void setRtng_Clr_Legal(String rtng_Clr_Legal) {
        this.rtng_Clr_Legal = rtng_Clr_Legal;
    }

    public String getRtng_Clr_Liquidity() {
        return this.rtng_Clr_Liquidity;
    }

    public void setRtng_Clr_Liquidity(String rtng_Clr_Liquidity) {
        this.rtng_Clr_Liquidity = rtng_Clr_Liquidity;
    }

    public String getRtng_Clr_Market() {
        return this.rtng_Clr_Market;
    }

    public void setRtng_Clr_Market(String rtng_Clr_Market) {
        this.rtng_Clr_Market = rtng_Clr_Market;
    }

    public String getRtng_Clr_People() {
        return this.rtng_Clr_People;
    }

    public void setRtng_Clr_People(String rtng_Clr_People) {
        this.rtng_Clr_People = rtng_Clr_People;
    }

    public String getRtng_Clr_Process_Risk() {
        return this.rtng_Clr_Process_Risk;
    }

    public void setRtng_Clr_Process_Risk(String rtng_Clr_Process_Risk) {
        this.rtng_Clr_Process_Risk = rtng_Clr_Process_Risk;
    }

    public String getRtng_Clr_Reputational() {
        return this.rtng_Clr_Reputational;
    }

    public void setRtng_Clr_Reputational(String rtng_Clr_Reputational) {
        this.rtng_Clr_Reputational = rtng_Clr_Reputational;
    }

    public String getRtng_Clr_Security_Risk() {
        return this.rtng_Clr_Security_Risk;
    }

    public void setRtng_Clr_Security_Risk(String rtng_Clr_Security_Risk) {
        this.rtng_Clr_Security_Risk = rtng_Clr_Security_Risk;
    }

    public String getRtng_Clr_Sourcing() {
        return this.rtng_Clr_Sourcing;
    }

    public void setRtng_Clr_Sourcing(String rtng_Clr_Sourcing) {
        this.rtng_Clr_Sourcing = rtng_Clr_Sourcing;
    }

    public String getRtng_Clr_Technology() {
        return this.rtng_Clr_Technology;
    }

    public void setRtng_Clr_Technology(String rtng_Clr_Technology) {
        this.rtng_Clr_Technology = rtng_Clr_Technology;
    }

    public String getRtng_Conduct() {
        return this.rtng_Conduct;
    }

    public void setRtng_Conduct(String rtng_Conduct) {
        this.rtng_Conduct = rtng_Conduct;
    }

    public String getRtng_Credit() {
        return this.rtng_Credit;
    }

    public void setRtng_Credit(String rtng_Credit) {
        this.rtng_Credit = rtng_Credit;
    }

    public String getRtng_Financial_Control() {
        return this.rtng_Financial_Control;
    }

    public void setRtng_Financial_Control(String rtng_Financial_Control) {
        this.rtng_Financial_Control = rtng_Financial_Control;
    }

    public String getRtng_Financial_Crime() {
        return this.rtng_Financial_Crime;
    }

    public void setRtng_Financial_Crime(String rtng_Financial_Crime) {
        this.rtng_Financial_Crime = rtng_Financial_Crime;
    }

    public String getRtng_Legal() {
        return this.rtng_Legal;
    }

    public void setRtng_Legal(String rtng_Legal) {
        this.rtng_Legal = rtng_Legal;
    }

    public String getRtng_Liquidity() {
        return this.rtng_Liquidity;
    }

    public void setRtng_Liquidity(String rtng_Liquidity) {
        this.rtng_Liquidity = rtng_Liquidity;
    }

    public String getRtng_Market() {
        return this.rtng_Market;
    }

    public void setRtng_Market(String rtng_Market) {
        this.rtng_Market = rtng_Market;
    }

    public String getRtng_People() {
        return this.rtng_People;
    }

    public void setRtng_People(String rtng_People) {
        this.rtng_People = rtng_People;
    }

    public String getRtng_Process_Risk() {
        return this.rtng_Process_Risk;
    }

    public void setRtng_Process_Risk(String rtng_Process_Risk) {
        this.rtng_Process_Risk = rtng_Process_Risk;
    }

    public String getRtng_Reputational() {
        return this.rtng_Reputational;
    }

    public void setRtng_Reputational(String rtng_Reputational) {
        this.rtng_Reputational = rtng_Reputational;
    }

    public BigDecimal getRtng_Scr_Business_Strategic() {
        return this.rtng_Scr_Business_Strategic;
    }

    public void setRtng_Scr_Business_Strategic(BigDecimal rtng_Scr_Business_Strategic) {
        this.rtng_Scr_Business_Strategic = rtng_Scr_Business_Strategic;
    }

    public BigDecimal getRtng_Scr_Change_Management() {
        return this.rtng_Scr_Change_Management;
    }

    public void setRtng_Scr_Change_Management(BigDecimal rtng_Scr_Change_Management) {
        this.rtng_Scr_Change_Management = rtng_Scr_Change_Management;
    }

    public BigDecimal getRtng_Scr_Conduct() {
        return this.rtng_Scr_Conduct;
    }

    public void setRtng_Scr_Conduct(BigDecimal rtng_Scr_Conduct) {
        this.rtng_Scr_Conduct = rtng_Scr_Conduct;
    }

    public BigDecimal getRtng_Scr_Credit() {
        return this.rtng_Scr_Credit;
    }

    public void setRtng_Scr_Credit(BigDecimal rtng_Scr_Credit) {
        this.rtng_Scr_Credit = rtng_Scr_Credit;
    }

    public BigDecimal getRtng_Scr_Financial_Control() {
        return this.rtng_Scr_Financial_Control;
    }

    public void setRtng_Scr_Financial_Control(BigDecimal rtng_Scr_Financial_Control) {
        this.rtng_Scr_Financial_Control = rtng_Scr_Financial_Control;
    }

    public BigDecimal getRtng_Scr_Financial_Crime() {
        return this.rtng_Scr_Financial_Crime;
    }

    public void setRtng_Scr_Financial_Crime(BigDecimal rtng_Scr_Financial_Crime) {
        this.rtng_Scr_Financial_Crime = rtng_Scr_Financial_Crime;
    }

    public BigDecimal getRtng_Scr_Legal() {
        return this.rtng_Scr_Legal;
    }

    public void setRtng_Scr_Legal(BigDecimal rtng_Scr_Legal) {
        this.rtng_Scr_Legal = rtng_Scr_Legal;
    }

    public BigDecimal getRtng_Scr_Liquidity() {
        return this.rtng_Scr_Liquidity;
    }

    public void setRtng_Scr_Liquidity(BigDecimal rtng_Scr_Liquidity) {
        this.rtng_Scr_Liquidity = rtng_Scr_Liquidity;
    }

    public BigDecimal getRtng_Scr_Market() {
        return this.rtng_Scr_Market;
    }

    public void setRtng_Scr_Market(BigDecimal rtng_Scr_Market) {
        this.rtng_Scr_Market = rtng_Scr_Market;
    }

    public BigDecimal getRtng_Scr_People() {
        return this.rtng_Scr_People;
    }

    public void setRtng_Scr_People(BigDecimal rtng_Scr_People) {
        this.rtng_Scr_People = rtng_Scr_People;
    }

    public BigDecimal getRtng_Scr_Process_Risk() {
        return this.rtng_Scr_Process_Risk;
    }

    public void setRtng_Scr_Process_Risk(BigDecimal rtng_Scr_Process_Risk) {
        this.rtng_Scr_Process_Risk = rtng_Scr_Process_Risk;
    }

    public BigDecimal getRtng_Scr_Reputational() {
        return this.rtng_Scr_Reputational;
    }

    public void setRtng_Scr_Reputational(BigDecimal rtng_Scr_Reputational) {
        this.rtng_Scr_Reputational = rtng_Scr_Reputational;
    }

    public BigDecimal getRtng_Scr_Security_Risk() {
        return this.rtng_Scr_Security_Risk;
    }

    public void setRtng_Scr_Security_Risk(BigDecimal rtng_Scr_Security_Risk) {
        this.rtng_Scr_Security_Risk = rtng_Scr_Security_Risk;
    }

    public BigDecimal getRtng_Scr_Sourcing() {
        return this.rtng_Scr_Sourcing;
    }

    public void setRtng_Scr_Sourcing(BigDecimal rtng_Scr_Sourcing) {
        this.rtng_Scr_Sourcing = rtng_Scr_Sourcing;
    }

    public BigDecimal getRtng_Scr_Technology() {
        return this.rtng_Scr_Technology;
    }

    public void setRtng_Scr_Technology(BigDecimal rtng_Scr_Technology) {
        this.rtng_Scr_Technology = rtng_Scr_Technology;
    }

    public String getRtng_Security_Risk() {
        return this.rtng_Security_Risk;
    }

    public void setRtng_Security_Risk(String rtng_Security_Risk) {
        this.rtng_Security_Risk = rtng_Security_Risk;
    }

    public String getRtng_Sourcing() {
        return this.rtng_Sourcing;
    }

    public void setRtng_Sourcing(String rtng_Sourcing) {
        this.rtng_Sourcing = rtng_Sourcing;
    }

    public String getRtng_Technology() {
        return this.rtng_Technology;
    }

    public void setRtng_Technology(String rtng_Technology) {
        this.rtng_Technology = rtng_Technology;
    }

    public BigDecimal getSecurity_Risk() {
        return this.security_Risk;
    }

    public void setSecurity_Risk(BigDecimal security_Risk) {
        this.security_Risk = security_Risk;
    }

    public String getSev_Rtng_Business_Strategic() {
        return this.sev_Rtng_Business_Strategic;
    }

    public void setSev_Rtng_Business_Strategic(String sev_Rtng_Business_Strategic) {
        this.sev_Rtng_Business_Strategic = sev_Rtng_Business_Strategic;
    }

    public String getSev_Rtng_Change_Management() {
        return this.sev_Rtng_Change_Management;
    }

    public void setSev_Rtng_Change_Management(String sev_Rtng_Change_Management) {
        this.sev_Rtng_Change_Management = sev_Rtng_Change_Management;
    }

    public String getSev_Rtng_Conduct() {
        return this.sev_Rtng_Conduct;
    }

    public void setSev_Rtng_Conduct(String sev_Rtng_Conduct) {
        this.sev_Rtng_Conduct = sev_Rtng_Conduct;
    }

    public String getSev_Rtng_Credit() {
        return this.sev_Rtng_Credit;
    }

    public void setSev_Rtng_Credit(String sev_Rtng_Credit) {
        this.sev_Rtng_Credit = sev_Rtng_Credit;
    }

    public String getSev_Rtng_Financial_Control() {
        return this.sev_Rtng_Financial_Control;
    }

    public void setSev_Rtng_Financial_Control(String sev_Rtng_Financial_Control) {
        this.sev_Rtng_Financial_Control = sev_Rtng_Financial_Control;
    }

    public String getSev_Rtng_Financial_Crime() {
        return this.sev_Rtng_Financial_Crime;
    }

    public void setSev_Rtng_Financial_Crime(String sev_Rtng_Financial_Crime) {
        this.sev_Rtng_Financial_Crime = sev_Rtng_Financial_Crime;
    }

    public String getSev_Rtng_Legal() {
        return this.sev_Rtng_Legal;
    }

    public void setSev_Rtng_Legal(String sev_Rtng_Legal) {
        this.sev_Rtng_Legal = sev_Rtng_Legal;
    }

    public String getSev_Rtng_Liquidity() {
        return this.sev_Rtng_Liquidity;
    }

    public void setSev_Rtng_Liquidity(String sev_Rtng_Liquidity) {
        this.sev_Rtng_Liquidity = sev_Rtng_Liquidity;
    }

    public String getSev_Rtng_Market() {
        return this.sev_Rtng_Market;
    }

    public void setSev_Rtng_Market(String sev_Rtng_Market) {
        this.sev_Rtng_Market = sev_Rtng_Market;
    }

    public String getSev_Rtng_People() {
        return this.sev_Rtng_People;
    }

    public void setSev_Rtng_People(String sev_Rtng_People) {
        this.sev_Rtng_People = sev_Rtng_People;
    }

    public String getSev_Rtng_Process_Risk() {
        return this.sev_Rtng_Process_Risk;
    }

    public void setSev_Rtng_Process_Risk(String sev_Rtng_Process_Risk) {
        this.sev_Rtng_Process_Risk = sev_Rtng_Process_Risk;
    }

    public String getSev_Rtng_Reputational() {
        return this.sev_Rtng_Reputational;
    }

    public void setSev_Rtng_Reputational(String sev_Rtng_Reputational) {
        this.sev_Rtng_Reputational = sev_Rtng_Reputational;
    }

    public String getSev_Rtng_Security_Risk() {
        return this.sev_Rtng_Security_Risk;
    }

    public void setSev_Rtng_Security_Risk(String sev_Rtng_Security_Risk) {
        this.sev_Rtng_Security_Risk = sev_Rtng_Security_Risk;
    }

    public String getSev_Rtng_Sourcing() {
        return this.sev_Rtng_Sourcing;
    }

    public void setSev_Rtng_Sourcing(String sev_Rtng_Sourcing) {
        this.sev_Rtng_Sourcing = sev_Rtng_Sourcing;
    }

    public String getSev_Rtng_Technology() {
        return this.sev_Rtng_Technology;
    }

    public void setSev_Rtng_Technology(String sev_Rtng_Technology) {
        this.sev_Rtng_Technology = sev_Rtng_Technology;
    }

    public BigDecimal getSourcing() {
        return this.sourcing;
    }

    public void setSourcing(BigDecimal sourcing) {
        this.sourcing = sourcing;
    }

    public String getStatusCdDesc() {
        return this.statusCdDesc;
    }

    public void setStatusCdDesc(String statusCdDesc) {
        this.statusCdDesc = statusCdDesc;
    }

    public BigDecimal getTechnology() {
        return this.technology;
    }

    public void setTechnology(BigDecimal technology) {
        this.technology = technology;
    }

    public Date getUpdateDtTm() {
        return this.updateDtTm;
    }

    public void setUpdateDtTm(Date updateDtTm) {
        this.updateDtTm = updateDtTm;
    }

    public String getVendorNm() {
        return this.vendorNm;
    }

    public void setVendorNm(String vendorNm) {
        this.vendorNm = vendorNm;
    }

    public String getNewEntity() {
        return newEntity;
    }

    public void setNewEntity(String newEntity) {
        this.newEntity = newEntity;
    }

    public String getPreviousAes() {
        return previousAes;
    }

    public void setPreviousAes(String previousAes) {
        this.previousAes = previousAes;
    }

    public String getPreviousCntrlRtng() {
        return previousCntrlRtng;
    }

    public void setPreviousCntrlRtng(String previousCntrlRtng) {
        this.previousCntrlRtng = previousCntrlRtng;
    }

    public String getRmrks() {
        return rmrks;
    }

    public void setRmrks(String rmrks) {
        this.rmrks = rmrks;
    }

    public String getFuncNm() {
        return funcNm;
    }

    public void setFuncNm(String funcNm) {
        this.funcNm = funcNm;
    }

}