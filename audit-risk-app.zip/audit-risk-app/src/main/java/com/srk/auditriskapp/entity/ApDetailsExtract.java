package com.srk.auditriskapp.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * The persistent class for the ap_details_extract database table.
 */
@Entity
@Table(name = "ap_details_extract")
@NamedQuery(name = "ApDetailsExtract.findAll", query = "SELECT a FROM ApDetailsExtract a")
public class ApDetailsExtract implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "AUDIT_PROJ_NUM")
    private Integer auditProjNum;

    @Column(name = "ACTIVITY_TYP_DESC")
    private String activityTypDesc;

    @Lob
    @Column(name = "AE_IDS")
    private String aeIds;

    @Column(name = "AGILE_FLG")
    private String agileFlg;

    @Column(name = "AUDIT_PROJ_ID")
    private String auditProjId;

    @Column(name = "AUDIT_PROJ_NM")
    private String auditProjNm;

    @Column(name = "AUDIT_SCOPE")
    private String auditScope;

    @Column(name = "PROJ_FUNC")
    private String projFunc;

    @Column(name = "CE_RATING")
    private String ceRating;

    @Column(name = "CNTNOUS_AUDITNG_FLG")
    private String cntnousAuditngFlg;

    @Column(name = "RPT_LOCTN")
    private String rptLoctn;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DT_TM")
    private Date createDtTm;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CROSS_BOARD_FLG")
    private String crossBoardFlg;

    @Lob
    @Column(name = "CROSS_BOARD_LOCTNS")
    private String crossBoardLoctns;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DUE_DT")
    private Date dueDt;

    @Column(name = "FAH_NM")
    private String fahNm;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "FIELD_WORK_END_DT")
    private Date fieldWorkEndDt;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "FIELD_WORK_START_DT")
    private Date fieldWorkStartDt;

    @Column(name = "FIELDWORK_BREAK")
    private Integer fieldworkBreak;

    @Column(name = "LAH_NM")
    private String lahNm;

    @Column(name = "MCA_RATING")
    private String mcaRating;

    @Column(name = "MNDAT_FLG")
    private String mndatFlg;

    @Column(name = "MNDAT_OVLP_FLG")
    private String mndatOvlpFlg;

    @Column(name = "MNGR_NM")
    private String mngrNm;

    @Column(name = "NATURE_DESC")
    private String natureDesc;

    @Lob
    @Column(name = "OR_IDS")
    private String orIds;

    @Column(name = "OTSRCNG_FLG")
    private String otsrcngFlg;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "OVWRT_DUE_DT")
    private Date ovwrtDueDt;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "OVWRT_FIELD_WORK_END_DT")
    private Date ovwrtFieldWorkEndDt;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "OVWRT_FIELD_WORK_START_DT")
    private Date ovwrtFieldWorkStartDt;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "PLAN_START_DT")
    private Date planStartDt;

    @Column(name = "PREDCTV_ANALYTIC_FLG")
    private String predctvAnalyticFlg;

    @Column(name = "PURE_BASEL_FLG")
    private String pureBaselFlg;

    private String rem;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "RPT_DT")
    private Date rptDt;

    @Column(name = "RPT_FLG")
    private String rptFlg;

    @Column(name = "PROJ_STS")
    private String projSts;

    @Column(name = "TOTAL_MAN_DAYS")
    private BigDecimal totalManDays;

    @Column(name = "TOTAL_MAN_HRS")
    private Integer totalManHrs;

    @Column(name = "TURN_AROUND_DAYS")
    private BigDecimal turnAroundDays;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATE_DT_TM")
    private Date updateDtTm;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    public ApDetailsExtract() {
    }

    public Integer getAuditProjNum() {
        return auditProjNum;
    }

    public void setAuditProjNum(Integer auditProjNum) {
        this.auditProjNum = auditProjNum;
    }

    public String getActivityTypDesc() {
        return activityTypDesc;
    }

    public void setActivityTypDesc(String activityTypDesc) {
        this.activityTypDesc = activityTypDesc;
    }

    public String getAeIds() {
        return aeIds;
    }

    public void setAeIds(String aeIds) {
        this.aeIds = aeIds;
    }

    public String getAgileFlg() {
        return agileFlg;
    }

    public void setAgileFlg(String agileFlg) {
        this.agileFlg = agileFlg;
    }

    public String getAuditProjId() {
        return auditProjId;
    }

    public void setAuditProjId(String auditProjId) {
        this.auditProjId = auditProjId;
    }

    public String getAuditProjNm() {
        return auditProjNm;
    }

    public void setAuditProjNm(String auditProjNm) {
        this.auditProjNm = auditProjNm;
    }

    public String getAuditScope() {
        return auditScope;
    }

    public void setAuditScope(String auditScope) {
        this.auditScope = auditScope;
    }

    public String getProjFunc() {
        return projFunc;
    }

    public void setProjFunc(String projFunc) {
        this.projFunc = projFunc;
    }

    public String getCeRating() {
        return ceRating;
    }

    public void setCeRating(String ceRating) {
        this.ceRating = ceRating;
    }

    public String getCntnousAuditngFlg() {
        return cntnousAuditngFlg;
    }

    public void setCntnousAuditngFlg(String cntnousAuditngFlg) {
        this.cntnousAuditngFlg = cntnousAuditngFlg;
    }

    public String getRptLoctn() {
        return rptLoctn;
    }

    public void setRptLoctn(String rptLoctn) {
        this.rptLoctn = rptLoctn;
    }

    public Date getCreateDtTm() {
        return createDtTm;
    }

    public void setCreateDtTm(Date createDtTm) {
        this.createDtTm = createDtTm;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCrossBoardFlg() {
        return crossBoardFlg;
    }

    public void setCrossBoardFlg(String crossBoardFlg) {
        this.crossBoardFlg = crossBoardFlg;
    }

    public String getCrossBoardLoctns() {
        return crossBoardLoctns;
    }

    public void setCrossBoardLoctns(String crossBoardLoctns) {
        this.crossBoardLoctns = crossBoardLoctns;
    }

    public Date getDueDt() {
        return dueDt;
    }

    public void setDueDt(Date dueDt) {
        this.dueDt = dueDt;
    }

    public String getFahNm() {
        return fahNm;
    }

    public void setFahNm(String fahNm) {
        this.fahNm = fahNm;
    }

    public Date getFieldWorkEndDt() {
        return fieldWorkEndDt;
    }

    public void setFieldWorkEndDt(Date fieldWorkEndDt) {
        this.fieldWorkEndDt = fieldWorkEndDt;
    }

    public Date getFieldWorkStartDt() {
        return fieldWorkStartDt;
    }

    public void setFieldWorkStartDt(Date fieldWorkStartDt) {
        this.fieldWorkStartDt = fieldWorkStartDt;
    }

    public Integer getFieldworkBreak() {
        return fieldworkBreak;
    }

    public void setFieldworkBreak(Integer fieldworkBreak) {
        this.fieldworkBreak = fieldworkBreak;
    }

    public String getLahNm() {
        return lahNm;
    }

    public void setLahNm(String lahNm) {
        this.lahNm = lahNm;
    }

    public String getMcaRating() {
        return mcaRating;
    }

    public void setMcaRating(String mcaRating) {
        this.mcaRating = mcaRating;
    }

    public String getMndatFlg() {
        return mndatFlg;
    }

    public void setMndatFlg(String mndatFlg) {
        this.mndatFlg = mndatFlg;
    }

    public String getMndatOvlpFlg() {
        return mndatOvlpFlg;
    }

    public void setMndatOvlpFlg(String mndatOvlpFlg) {
        this.mndatOvlpFlg = mndatOvlpFlg;
    }

    public String getMngrNm() {
        return mngrNm;
    }

    public void setMngrNm(String mngrNm) {
        this.mngrNm = mngrNm;
    }

    public String getNatureDesc() {
        return natureDesc;
    }

    public void setNatureDesc(String natureDesc) {
        this.natureDesc = natureDesc;
    }

    public String getOrIds() {
        return orIds;
    }

    public void setOrIds(String orIds) {
        this.orIds = orIds;
    }

    public String getOtsrcngFlg() {
        return otsrcngFlg;
    }

    public void setOtsrcngFlg(String otsrcngFlg) {
        this.otsrcngFlg = otsrcngFlg;
    }

    public Date getOvwrtDueDt() {
        return ovwrtDueDt;
    }

    public void setOvwrtDueDt(Date ovwrtDueDt) {
        this.ovwrtDueDt = ovwrtDueDt;
    }

    public Date getOvwrtFieldWorkEndDt() {
        return ovwrtFieldWorkEndDt;
    }

    public void setOvwrtFieldWorkEndDt(Date ovwrtFieldWorkEndDt) {
        this.ovwrtFieldWorkEndDt = ovwrtFieldWorkEndDt;
    }

    public Date getOvwrtFieldWorkStartDt() {
        return ovwrtFieldWorkStartDt;
    }

    public void setOvwrtFieldWorkStartDt(Date ovwrtFieldWorkStartDt) {
        this.ovwrtFieldWorkStartDt = ovwrtFieldWorkStartDt;
    }

    public Date getPlanStartDt() {
        return planStartDt;
    }

    public void setPlanStartDt(Date planStartDt) {
        this.planStartDt = planStartDt;
    }

    public String getPredctvAnalyticFlg() {
        return predctvAnalyticFlg;
    }

    public void setPredctvAnalyticFlg(String predctvAnalyticFlg) {
        this.predctvAnalyticFlg = predctvAnalyticFlg;
    }

    public String getPureBaselFlg() {
        return pureBaselFlg;
    }

    public void setPureBaselFlg(String pureBaselFlg) {
        this.pureBaselFlg = pureBaselFlg;
    }

    public String getRem() {
        return rem;
    }

    public void setRem(String rem) {
        this.rem = rem;
    }

    public Date getRptDt() {
        return rptDt;
    }

    public void setRptDt(Date rptDt) {
        this.rptDt = rptDt;
    }

    public String getRptFlg() {
        return rptFlg;
    }

    public void setRptFlg(String rptFlg) {
        this.rptFlg = rptFlg;
    }

    public String getProjSts() {
        return projSts;
    }

    public void setProjSts(String projSts) {
        this.projSts = projSts;
    }

    public BigDecimal getTotalManDays() {
        return totalManDays;
    }

    public void setTotalManDays(BigDecimal totalManDays) {
        this.totalManDays = totalManDays;
    }

    public Integer getTotalManHrs() {
        return totalManHrs;
    }

    public void setTotalManHrs(Integer totalManHrs) {
        this.totalManHrs = totalManHrs;
    }

    public BigDecimal getTurnAroundDays() {
        return turnAroundDays;
    }

    public void setTurnAroundDays(BigDecimal turnAroundDays) {
        this.turnAroundDays = turnAroundDays;
    }

    public Date getUpdateDtTm() {
        return updateDtTm;
    }

    public void setUpdateDtTm(Date updateDtTm) {
        this.updateDtTm = updateDtTm;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

}