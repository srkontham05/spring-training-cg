package com.srk.auditriskapp.model;

public class APExportRequestModel {

	private String fromUpdatedDate;
	private String toUpdatedDate;

	// AP Details Common Filter Columns
	private String auditProjId;
	private String auditProjNm;
	private String projSts;
	// AP Details Filter Columns
	private String activityTypDesc;
	private String natureDesc;
	private String projFunc;
	private String rptLoctn;
	private String fahNm;
	private String lahNm;
	private String mngrNm;
	private String agileFlg;
	// AP AE Details Filter Columns
	private String aeId;
	private String aeNm;
	private String aePriFunc;
	// AP OR Details Filter Columns
	private String orId;

	private String timestamp;

	public String getFromUpdatedDate() {
		return fromUpdatedDate;
	}

	public void setFromUpdatedDate(String fromUpdatedDate) {
		this.fromUpdatedDate = fromUpdatedDate;
	}

	public String getToUpdatedDate() {
		return toUpdatedDate;
	}

	public void setToUpdatedDate(String toUpdatedDate) {
		this.toUpdatedDate = toUpdatedDate;
	}

	public String getAuditProjId() {
		return auditProjId;
	}

	public void setAuditProjId(String auditProjId) {
		this.auditProjId = auditProjId;
	}

	public String getAuditProjNm() {
		return auditProjNm;
	}

	public void setAuditProjNm(String auditProjNm) {
		this.auditProjNm = auditProjNm;
	}

	public String getProjSts() {
		return projSts;
	}

	public void setProjSts(String projSts) {
		this.projSts = projSts;
	}

	public String getActivityTypDesc() {
		return activityTypDesc;
	}

	public void setActivityTypDesc(String activityTypDesc) {
		this.activityTypDesc = activityTypDesc;
	}

	public String getNatureDesc() {
		return natureDesc;
	}

	public void setNatureDesc(String natureDesc) {
		this.natureDesc = natureDesc;
	}

	public String getProjFunc() {
		return projFunc;
	}

	public void setProjFunc(String projFunc) {
		this.projFunc = projFunc;
	}

	public String getRptLoctn() {
		return rptLoctn;
	}

	public void setRptLoctn(String rptLoctn) {
		this.rptLoctn = rptLoctn;
	}

	public String getFahNm() {
		return fahNm;
	}

	public void setFahNm(String fahNm) {
		this.fahNm = fahNm;
	}

	public String getLahNm() {
		return lahNm;
	}

	public void setLahNm(String lahNm) {
		this.lahNm = lahNm;
	}

	public String getMngrNm() {
		return mngrNm;
	}

	public void setMngrNm(String mngrNm) {
		this.mngrNm = mngrNm;
	}

	public String getAgileFlg() {
		return agileFlg;
	}

	public void setAgileFlg(String agileFlg) {
		this.agileFlg = agileFlg;
	}

	public String getAeId() {
		return aeId;
	}

	public void setAeId(String aeId) {
		this.aeId = aeId;
	}

	public String getAeNm() {
		return aeNm;
	}

	public void setAeNm(String aeNm) {
		this.aeNm = aeNm;
	}

	public String getAePriFunc() {
		return aePriFunc;
	}

	public void setAePriFunc(String aePriFunc) {
		this.aePriFunc = aePriFunc;
	}

	public String getOrId() {
		return orId;
	}

	public void setOrId(String orId) {
		this.orId = orId;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

}
