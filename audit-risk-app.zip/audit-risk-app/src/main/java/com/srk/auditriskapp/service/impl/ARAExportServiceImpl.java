package com.srk.auditriskapp.service.impl;

import com.srk.auditriskapp.constants.Const;
import com.srk.auditriskapp.entity.AeExtract;
import com.srk.auditriskapp.entity.ApAeDetailsExtract;
import com.srk.auditriskapp.entity.ApDetailsExtract;
import com.srk.auditriskapp.entity.ApOrDetailsExtract;
import com.srk.auditriskapp.model.AEExportRequestModel;
import com.srk.auditriskapp.model.APExportRequestModel;
import com.srk.auditriskapp.model.HeaderModel;
import com.srk.auditriskapp.service.ARAExportService;
import com.srk.auditriskapp.utils.ARAExcelUtility;
import com.srk.auditriskapp.utils.AuditDateUtils;
import com.srk.auditriskapp.utils.AuditUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.StatelessSession;
import org.json.simple.parser.ParseException;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.*;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
@Transactional
public class ARAExportServiceImpl implements ARAExportService {

    private static final Logger LOGGER = Logger.getLogger(ARAExportServiceImpl.class.getName());
    private static SimpleDateFormat formatter = new SimpleDateFormat(Const.MIS_EXPORT.REPORT_DESC_DATE_FORMAT);

    @PersistenceContext
    private EntityManager em;

    @Resource
    private Environment env;

    ARAExcelUtility excelUtil = new ARAExcelUtility();

    private static SimpleDateFormat noTimeDateFormatter = new SimpleDateFormat(Const.REQ_RES_DATE_FORMAT);

    /*
        @PostConstruct
        public void initalization() {
            try {
                sheetName = Const.MIS_EXPORT.MIS_SHEET_NAMES;
                generateColumnMpngList();
            } catch (ParseException e) {
                LOGGER.log(Level.SEVERE, "Could not export", e);
            }
        }
    */
    @Override
    public HttpServletResponse aeExport(HttpServletResponse response, AEExportRequestModel exportModel,
                                        HeaderModel header) throws ParseException, IOException {

        Date assmtFromDate = null;
        Date assmtToDate = null;
        Date updateFromDate = null;
        Date updateToDate = null;
        StringBuilder descirption = new StringBuilder();

        descirption.append("Report Date :" + new Date() + "\n");
        Map<String, Object> parameterMap = new LinkedHashMap<>();

        if (null != exportModel.getFromAssmtPeriod() && null != exportModel.getToAssmtPeriod()) {
            assmtFromDate = AuditDateUtils.convertUTCToSGT(exportModel.getFromAssmtPeriod());
            assmtToDate = AuditDateUtils.convertUTCToSGT(exportModel.getToAssmtPeriod());
            parameterMap.put(Const.MIS_PARAMETERS.ASSMT_FROM_DATE, assmtFromDate);
            parameterMap.put(Const.MIS_PARAMETERS.ASSMT_TO_DATE, assmtToDate);
            descirption.append("Assessment Period Range : From " + noTimeDateFormatter.format(assmtFromDate) + " To "
                    + noTimeDateFormatter.format(assmtToDate) + "\n");
        }

        if (null != exportModel.getFromUpdatedDate() && null != exportModel.getToUpdatedDate()) {
            updateFromDate = AuditDateUtils.convertUTCToSGT(exportModel.getFromUpdatedDate());
            updateToDate = AuditDateUtils.convertUTCToSGT(exportModel.getToUpdatedDate());
            parameterMap.put(Const.MIS_PARAMETERS.UPDATE_FROM_DATE, updateFromDate);
            parameterMap.put(Const.MIS_PARAMETERS.UPDATE_TO_DATE, updateToDate);
            descirption.append("Updated Date Range : From " + noTimeDateFormatter.format(updateFromDate) + " To "
                    + noTimeDateFormatter.format(updateToDate) + "\n");
        }

        if (null != exportModel.getEntity() && !exportModel.getEntity().isEmpty()) {
            parameterMap.put(Const.MIS_PARAMETERS.ENTITY, exportModel.getEntity());
            descirption.append("Entity: " + exportModel.getEntity() + "\n");
        }

        if (null != exportModel.getFunction() && !exportModel.getFunction().isEmpty()) {
            parameterMap.put(Const.MIS_PARAMETERS.FUNCTION, exportModel.getFunction());
            descirption.append("Function: " + exportModel.getFunction() + "\n");
        }

        if (null != exportModel.getManager() && !exportModel.getManager().isEmpty()) {
            parameterMap.put(Const.MIS_PARAMETERS.MANAGER, exportModel.getManager());
            descirption.append("Manager: " + exportModel.getManager() + "\n");
        }

        if (null != exportModel.getOrgUnit() && !exportModel.getOrgUnit().isEmpty()) {
            parameterMap.put(Const.MIS_PARAMETERS.UNIT, exportModel.getOrgUnit());
            descirption.append("Unit: " + exportModel.getOrgUnit() + "\n");
        }

        if (null != exportModel.getStatus() && !exportModel.getStatus().isEmpty()) {
            parameterMap.put(Const.MIS_PARAMETERS.STATUS, exportModel.getStatus());
            descirption.append("Status: " + exportModel.getStatus() + "\n");
        }

        String fileNm = Const.MIS_EXPORT.MIS_SHEET_NAMES + new Timestamp(new Date().getTime());
        buildXlsResponse(response, fileNm);
        SXSSFWorkbook wb = getStream(parameterMap, response,
                exportModel == null ? new Date().toString() : exportModel.getTimestamp());
        write2WorkBook(response, wb);
        return response;
    }

    private SXSSFWorkbook getStream(Map<String, Object> parameterMap, HttpServletResponse response, String descirption)
            throws ParseException {

        String sheetName = Const.MIS_EXPORT.MIS_SHEET_NAMES;
        Map<String, List<Map<Integer, String>>> columnMpng = generateColumnMpngList(sheetName);

        Session session = null;
        StatelessSession openSession = null;
        boolean assmtDtParam = false;
        boolean updateDtParam = false;
        boolean setEntity = false;
        boolean setFunction = false;
        boolean setManager = false;
        boolean setUnit = false;
        boolean setStatus = false;
        SXSSFWorkbook wb = null;
        try {
            session = em.unwrap(Session.class);
            openSession = session.getSessionFactory().openStatelessSession();
            Expression<String> exp = null;
            CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
            CriteriaQuery<AeExtract> criteriaQuery = criteriaBuilder.createQuery(AeExtract.class);
            Root<AeExtract> root = criteriaQuery.from(AeExtract.class);
            List<Predicate> predicates = new ArrayList<>();

            if (null != parameterMap.get(Const.MIS_PARAMETERS.ASSMT_FROM_DATE)
                    && null != parameterMap.get(Const.MIS_PARAMETERS.ASSMT_TO_DATE)) {
                exp = root.get(Const.MIS_PARAMETERS.VIEW_COLUMN_ASM_DT);
                Predicate fromStrtDtTm = criteriaBuilder.greaterThanOrEqualTo(exp.as(Date.class),
                        criteriaBuilder.parameter(Date.class, Const.MIS_PARAMETERS.ASSMT_FROM_DATE));
                Predicate toStrtDtTm = criteriaBuilder.lessThanOrEqualTo(exp.as(Date.class),
                        criteriaBuilder.parameter(Date.class, Const.MIS_PARAMETERS.ASSMT_TO_DATE));
                Predicate and = criteriaBuilder.and(fromStrtDtTm, toStrtDtTm);
                predicates.add(and);
                assmtDtParam = true;
            }

            if (null != parameterMap.get(Const.MIS_PARAMETERS.UPDATE_FROM_DATE)
                    && null != parameterMap.get(Const.MIS_PARAMETERS.UPDATE_TO_DATE)) {
                exp = root.get(Const.MIS_PARAMETERS.VIEW_COLUMN_UPD_DT);
                Predicate fromStrtDtTm = criteriaBuilder.greaterThanOrEqualTo(exp.as(Date.class),
                        criteriaBuilder.parameter(Date.class, Const.MIS_PARAMETERS.UPDATE_FROM_DATE));
                Predicate toStrtDtTm = criteriaBuilder.lessThanOrEqualTo(exp.as(Date.class),
                        criteriaBuilder.parameter(Date.class, Const.MIS_PARAMETERS.UPDATE_TO_DATE));
                Predicate and = criteriaBuilder.and(fromStrtDtTm, toStrtDtTm);
                predicates.add(and);
                updateDtParam = true;
            }

            if (null != parameterMap.get(Const.MIS_PARAMETERS.ENTITY)) {
                exp = root.get(Const.MIS_PARAMETERS.VIEW_COLUMN_ENTITY);
                Expression<String> param = criteriaBuilder.parameter(String.class, Const.MIS_PARAMETERS.ENTITY);
                predicates.add(criteriaBuilder.like(exp, param));
                setEntity = true;
            }

            if (null != parameterMap.get(Const.MIS_PARAMETERS.FUNCTION)) {
                exp = root.get(Const.MIS_PARAMETERS.VIEW_COLUMN_FUNCTION);
                Expression<String> param = criteriaBuilder.parameter(String.class, Const.MIS_PARAMETERS.FUNCTION);
                predicates.add(criteriaBuilder.like(exp, param));
                setFunction = true;
            }

            if (null != parameterMap.get(Const.MIS_PARAMETERS.MANAGER)) {
                exp = root.get(Const.MIS_PARAMETERS.VIEW_COLUMN_MANAGER);
                Expression<String> param = criteriaBuilder.parameter(String.class, Const.MIS_PARAMETERS.MANAGER);
                predicates.add(criteriaBuilder.like(exp, param));
                setManager = true;
            }

            if (null != parameterMap.get(Const.MIS_PARAMETERS.UNIT)) {
                exp = root.get(Const.MIS_PARAMETERS.VIEW_COLUMN_UNIT);
                Expression<String> param = criteriaBuilder.parameter(String.class, Const.MIS_PARAMETERS.UNIT);
                predicates.add(criteriaBuilder.like(exp, param));
                setUnit = true;

            }

            if (null != parameterMap.get(Const.MIS_PARAMETERS.STATUS)) {
                exp = root.get(Const.MIS_PARAMETERS.VIEW_COLUMN_STATUS);
                Expression<String> param = criteriaBuilder.parameter(String.class, Const.MIS_PARAMETERS.STATUS);
                predicates.add(criteriaBuilder.like(exp, param));
                setStatus = true;

            }

            criteriaQuery.select(root).where(criteriaBuilder.and(predicates.toArray(new Predicate[]{})));

            Query query = em.createQuery(criteriaQuery);
            String queryStrng = query.unwrap(org.hibernate.Query.class).getQueryString();
            org.hibernate.Query targetQuery = openSession.createQuery(queryStrng);

            if (assmtDtParam) {
                targetQuery = targetQuery.setParameter(Const.MIS_PARAMETERS.ASSMT_FROM_DATE,
                        parameterMap.get(Const.MIS_PARAMETERS.ASSMT_FROM_DATE));
                targetQuery = targetQuery.setParameter(Const.MIS_PARAMETERS.ASSMT_TO_DATE,
                        parameterMap.get(Const.MIS_PARAMETERS.ASSMT_TO_DATE));
            }

            if (updateDtParam) {
                targetQuery = targetQuery.setParameter(Const.MIS_PARAMETERS.UPDATE_FROM_DATE,
                        parameterMap.get(Const.MIS_PARAMETERS.UPDATE_FROM_DATE));
                targetQuery = targetQuery.setParameter(Const.MIS_PARAMETERS.UPDATE_TO_DATE,
                        parameterMap.get(Const.MIS_PARAMETERS.UPDATE_TO_DATE));
            }

            if (setEntity) {
                targetQuery = targetQuery.setParameter(Const.MIS_PARAMETERS.ENTITY,
                        parameterMap.get(Const.MIS_PARAMETERS.ENTITY));
            }

            if (setFunction) {
                targetQuery = targetQuery.setParameter(Const.MIS_PARAMETERS.FUNCTION,
                        parameterMap.get(Const.MIS_PARAMETERS.FUNCTION));
            }

            if (setManager) {
                targetQuery = targetQuery.setParameter(Const.MIS_PARAMETERS.MANAGER,
                        parameterMap.get(Const.MIS_PARAMETERS.MANAGER));
            }

            if (setUnit) {
                targetQuery = targetQuery.setParameter(Const.MIS_PARAMETERS.UNIT,
                        parameterMap.get(Const.MIS_PARAMETERS.UNIT));
            }

            if (setStatus) {
                targetQuery = targetQuery.setParameter(Const.MIS_PARAMETERS.STATUS,
                        parameterMap.get(Const.MIS_PARAMETERS.STATUS));
            }

            ScrollableResults scrollResult = targetQuery.setReadOnly(true).scroll(ScrollMode.FORWARD_ONLY);
            int counter = 0;
            wb = excelUtil.createWorkbook();
            genereateColHeaders(wb, descirption, sheetName);

            while (scrollResult.next()) {
                if (++counter > 0 && counter % 100 == 0) {
                    LOGGER.finer("fetched " + counter + " entities");
                    excelUtil.autoResizeColumns(113, wb.getSheetAt(0));
                }
                AeExtract misEntity = (AeExtract) scrollResult.get()[0];
                generateExcelFormatData(misEntity, wb, sheetName, columnMpng);
            }

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Could not export", e);
        } finally {
            openSession.close();
        }
        return wb;
    }

    private void buildXlsResponse(HttpServletResponse response, String exportName) {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", String.format("inline; filename=\"" + exportName + "\""));
        response.setHeader("Cache-Control", "private, must-revalidate");
        response.setHeader("Pragma", "private, no-cache");
    }

    private void genereateColHeaders(SXSSFWorkbook wb, String sheetName, String description) throws ParseException {
        String jsonString = env.getRequiredProperty(Const.MIS_EXPORT.SHEET_COL_HEADER_PREFIX + "sheet0");
        Map<Integer, String> columsList = AuditUtils.getRequiredValuesFromJson(jsonString, "columnDisplayName");
        if (description.length() > 1) {
            excelUtil.createHeader(wb, columsList, sheetName, description);
        } else {
            excelUtil.createHeader(wb, columsList, sheetName, null);
        }
    }

    private Map<String, List<Map<Integer, String>>> generateColumnMpngList(String sheetName) throws ParseException {
        Map<String, List<Map<Integer, String>>> columnMpng = new HashMap<>();
        List<Map<Integer, String>> dataMapperList = null;
        dataMapperList = new ArrayList<>();
        String jsonString = env.getRequiredProperty(Const.MIS_EXPORT.SHEET_COL_HEADER_PREFIX + "sheet0");
        dataMapperList.add(AuditUtils.getRequiredValuesFromJson(jsonString, "columnName"));
        dataMapperList.add(AuditUtils.getRequiredValuesFromJson(jsonString, "dataType"));
        columnMpng.put(sheetName, dataMapperList);
        return columnMpng;
    }

    private void generateExcelFormatData(Object misObj, SXSSFWorkbook wb, Map<String, List<Map<Integer, String>>> columnMapping,
                                         String sheetName) throws ParseException {
        if (null == misObj)
            return;
        excelUtil.processDataByRow(wb, columnMapping, AuditUtils.convertObjToJSON(misObj), sheetName);
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public void setEnv(Environment env) {
        this.env = env;
    }

    @Override
    public HttpServletResponse apExport(HttpServletResponse response, APExportRequestModel exportModel,
                                        HeaderModel header) throws ParseException, IOException {
        LOGGER.info("Inside apExport()");
        Date updateFromDate = null;
        Date updateToDate = null;

        Map<String, Object> parameterMap = new LinkedHashMap<>();
        StringBuilder exportFilterFields = new StringBuilder();

        if (null != exportModel.getFromUpdatedDate() && null != exportModel.getToUpdatedDate()) {
            updateFromDate = AuditDateUtils.convertUTCToSGT(exportModel.getFromUpdatedDate());
            updateToDate = AuditDateUtils.convertUTCToSGT(exportModel.getToUpdatedDate());
            parameterMap.put(Const.AP_MIS_PARAMETERS.UPDATE_FROM_DATE, updateFromDate);
            parameterMap.put(Const.AP_MIS_PARAMETERS.UPDATE_TO_DATE, updateToDate);
            exportFilterFields.append("Updated Date Range : From " + noTimeDateFormatter.format(updateFromDate) + " To "
                    + noTimeDateFormatter.format(updateToDate) + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getAuditProjId())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.PROJ_ID, exportModel.getAuditProjId());
            exportFilterFields.append("Project Id: " + exportModel.getAuditProjId() + "\r\n");
        }
        if (StringUtils.isNotBlank(exportModel.getAuditProjNm())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.PROJ_NAME, exportModel.getAuditProjNm());
            exportFilterFields.append("Project Name: " + exportModel.getAuditProjNm() + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getProjSts())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.PROJ_STATUS, exportModel.getProjSts());
            exportFilterFields.append("Project Status: " + exportModel.getProjSts() + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getActivityTypDesc())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.ACTIVITY_TYPE, exportModel.getActivityTypDesc());
            exportFilterFields.append("Activity Type: " + exportModel.getActivityTypDesc() + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getNatureDesc())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.NATURE, exportModel.getNatureDesc());
            exportFilterFields.append("Nature: " + exportModel.getNatureDesc() + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getProjFunc())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.PROJ_FUNC, exportModel.getProjFunc());
            exportFilterFields.append("Project Function: " + exportModel.getProjFunc() + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getRptLoctn())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.RPT_LOCTN, exportModel.getRptLoctn());
            exportFilterFields.append("Report Location: " + exportModel.getRptLoctn() + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getFahNm())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.FAH, exportModel.getFahNm());
            exportFilterFields.append("FAH: " + exportModel.getFahNm() + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getLahNm())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.LAH, exportModel.getLahNm());
            exportFilterFields.append("LAH: " + exportModel.getLahNm() + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getMngrNm())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.MANAGER, exportModel.getMngrNm());
            exportFilterFields.append("Manager: " + exportModel.getMngrNm() + "\r\n");
        }
        if (StringUtils.isNotBlank(exportModel.getAgileFlg())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.AGILE_FLG, exportModel.getAgileFlg());
            exportFilterFields.append("Agile Flag: " + exportModel.getAgileFlg() + "\r\n");
        }
        if (StringUtils.isNotBlank(exportModel.getAeId())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.AE_ID, exportModel.getAeId());
            exportFilterFields.append("AE Id: " + exportModel.getAeId() + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getAeNm())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.AE_NAME, exportModel.getAeNm());
            exportFilterFields.append("AE Name: " + exportModel.getAeNm() + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getAePriFunc())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.AE_PRI_FUNC, exportModel.getAePriFunc());
            exportFilterFields.append("AE Primary Function: " + exportModel.getAePriFunc() + "\r\n");
        }

        if (StringUtils.isNotBlank(exportModel.getOrId())) {
            parameterMap.put(Const.AP_MIS_PARAMETERS.OR_ID, exportModel.getOrId());
            exportFilterFields.append("OSP OR Id: " + exportModel.getOrId() + "\r\n");
        }

        String fileName = env.getRequiredProperty(Const.MIS_EXPORT.AP_MIS_REPORT_FILE_NAME);

        LOGGER.info("Preparing MIS Report");
        buildXlsResponse(response, fileName);
        SXSSFWorkbook wrokBook = getStream(parameterMap, response, exportModel);
        write2WorkBook(response, wrokBook);
        LOGGER.info("Prepared MIS Report");
        return response;
    }

    private void write2WorkBook(HttpServletResponse response, SXSSFWorkbook workbook) throws IOException {
        if (null != workbook) {
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
            workbook.write(bout);
            byte[] outArray = bout.toByteArray();
            response.setContentLength(outArray.length);

            OutputStream stream = response.getOutputStream();
            stream.write(outArray);
            stream.flush();
            stream.close();

            workbook.dispose();
            bout.close();
        }
    }

    private SXSSFWorkbook getStream(Map<String, Object> parameterMap, HttpServletResponse response,
                                    APExportRequestModel exportModel) throws ParseException {
        LOGGER.info("Inside getStream()");

        String[] sheetNames = env.getRequiredProperty(Const.MIS_EXPORT.AP_MIS_REPORT_SHEET_NAMES).split(",");
        String[] headerDesc = getSheetsDescription(exportModel.getTimestamp(), sheetNames.length);
        Map<String, List<Map<Integer, String>>> columnMapping = generateColumnMpngList(sheetNames);

        Map<String, Map<String, Boolean>> filterMapping = generateFilterMapping(sheetNames);

        Session session = null;
        StatelessSession openSession = null;
        SXSSFWorkbook workBook = null;

        boolean setUpdateDtTm = false;

        boolean setProjId = false;
        boolean setProjName = false;
        boolean setProjStatus = false;

        boolean setActivityType = false;
        boolean setNature = false;
        boolean setProjFunc = false;
        boolean setRptLoctn = false;
        boolean setFah = false;
        boolean setLah = false;
        boolean setManager = false;
        boolean setAgileFlg = false;

        boolean setAeId = false;
        boolean setAeName = false;
        boolean setAePriFunc = false;

        boolean setOrId = false;

        try {
            session = em.unwrap(Session.class);
            openSession = session.getSessionFactory().openStatelessSession();

            CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();

            CriteriaQuery<ApDetailsExtract> apDetailsExtractCriteriaQuery = criteriaBuilder.createQuery(ApDetailsExtract.class);
            Root<ApDetailsExtract> apDetailsExtractRoot = apDetailsExtractCriteriaQuery.from(ApDetailsExtract.class);

            CriteriaQuery<ApAeDetailsExtract> apAeDetailsExtractCriteriaQuery = criteriaBuilder.createQuery(ApAeDetailsExtract.class);
            Root<ApAeDetailsExtract> apAeDetailsExtractRoot = apAeDetailsExtractCriteriaQuery.from(ApAeDetailsExtract.class);

            CriteriaQuery<ApOrDetailsExtract> apOrDetailsExtractCriteriaQuery = criteriaBuilder.createQuery(ApOrDetailsExtract.class);
            Root<ApOrDetailsExtract> apOrDetailsExtractRoot = apOrDetailsExtractCriteriaQuery.from(ApOrDetailsExtract.class);

            Expression<String> expApDetails = null;
            List<Predicate> predicatesApDetails = new ArrayList<>();

            Expression<String> expApAeDetails = null;
            List<Predicate> predicatesApAeDetails = new ArrayList<>();

            Expression<String> expApOrDetails = null;
            List<Predicate> predicatesApOrDetails = new ArrayList<>();


            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.UPDATE_FROM_DATE)
                    && null != parameterMap.get(Const.AP_MIS_PARAMETERS.UPDATE_TO_DATE)) {

                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.UPDATE_DT_TM);
                Predicate fromStrtDtTm = criteriaBuilder.greaterThanOrEqualTo(expApDetails.as(Date.class),
                        criteriaBuilder.parameter(Date.class, Const.AP_MIS_PARAMETERS.UPDATE_FROM_DATE));
                Predicate toStrtDtTm = criteriaBuilder.lessThanOrEqualTo(expApDetails.as(Date.class),
                        criteriaBuilder.parameter(Date.class, Const.AP_MIS_PARAMETERS.UPDATE_TO_DATE));
                Predicate and = criteriaBuilder.and(fromStrtDtTm, toStrtDtTm);
                predicatesApDetails.add(and);
                setUpdateDtTm = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_ID)) {
                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.PROJ_ID);
                predicatesApDetails.add(criteriaBuilder.like(expApDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.PROJ_ID)));

                expApAeDetails = apAeDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.PROJ_ID);
                predicatesApAeDetails.add(criteriaBuilder.like(expApAeDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.PROJ_ID)));

                expApOrDetails = apOrDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.PROJ_ID);
                predicatesApOrDetails.add(criteriaBuilder.like(expApOrDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.PROJ_ID)));

                setProjId = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_NAME)) {
                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.PROJ_NAME);
                predicatesApDetails.add(criteriaBuilder.like(expApDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.PROJ_NAME)));

                expApAeDetails = apAeDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.PROJ_NAME);
                predicatesApAeDetails.add(criteriaBuilder.like(expApAeDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.PROJ_NAME)));

                expApOrDetails = apOrDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.PROJ_NAME);
                predicatesApOrDetails.add(criteriaBuilder.like(expApOrDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.PROJ_NAME)));

                setProjName = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_STATUS)) {
                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.PROJ_STATUS);
                predicatesApDetails.add(criteriaBuilder.like(expApDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.PROJ_STATUS)));

                expApAeDetails = apAeDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.PROJ_STATUS);
                predicatesApAeDetails.add(criteriaBuilder.like(expApAeDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.PROJ_STATUS)));

                expApOrDetails = apOrDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.PROJ_STATUS);
                predicatesApOrDetails.add(criteriaBuilder.like(expApOrDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.PROJ_STATUS)));

                setProjStatus = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.ACTIVITY_TYPE)) {
                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.ACTIVITY_TYPE);
                predicatesApDetails.add(criteriaBuilder.like(expApDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.ACTIVITY_TYPE)));
                setActivityType = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.NATURE)) {
                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.NATURE);
                predicatesApDetails.add(criteriaBuilder.like(expApDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.NATURE)));
                setNature = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_FUNC)) {
                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.PROJ_FUNC);
                predicatesApDetails.add(criteriaBuilder.like(expApDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.PROJ_FUNC)));
                setProjFunc = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.RPT_LOCTN)) {
                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.RPT_LOCTN);
                predicatesApDetails.add(criteriaBuilder.like(expApDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.RPT_LOCTN)));
                setRptLoctn = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.LAH)) {
                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.LAH);
                predicatesApDetails.add(criteriaBuilder.like(expApDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.LAH)));
                setLah = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.FAH)) {
                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.FAH);
                predicatesApDetails.add(criteriaBuilder.like(expApDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.FAH)));
                setFah = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.MANAGER)) {
                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.MANAGER);
                predicatesApDetails.add(criteriaBuilder.like(expApDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.MANAGER)));
                setManager = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.AGILE_FLG)) {
                expApDetails = apDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.AGILE_FLG);
                predicatesApDetails.add(criteriaBuilder.like(expApDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.AGILE_FLG)));
                setAgileFlg = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.AE_ID)) {
                expApAeDetails = apAeDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.AE_ID);
                predicatesApAeDetails.add(criteriaBuilder.like(expApAeDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.AE_ID)));
                setAeId = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.AE_NAME)) {
                expApAeDetails = apAeDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.AE_NAME);
                predicatesApAeDetails.add(criteriaBuilder.like(expApAeDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.AE_NAME)));
                setAeName = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.AE_PRI_FUNC)) {
                expApAeDetails = apAeDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.AE_PRI_FUNC);
                predicatesApAeDetails.add(criteriaBuilder.like(expApAeDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.AE_PRI_FUNC)));
                setAePriFunc = true;
            }

            if (null != parameterMap.get(Const.AP_MIS_PARAMETERS.OR_ID)) {
                expApOrDetails = apOrDetailsExtractRoot.get(Const.AP_MIS_PARAMETERS.OR_ID);
                predicatesApOrDetails.add(criteriaBuilder.like(expApOrDetails,
                        criteriaBuilder.parameter(String.class, Const.AP_MIS_PARAMETERS.OR_ID)));
                setOrId = true;
            }

            // List<Order> orderList = new ArrayList<>();
            // orderList.add(criteriaBuilder.asc(root.get("aeId")));
            // criteriaQuery.orderBy(orderList);

            // Filtering AP Details
            apDetailsExtractCriteriaQuery.select(apDetailsExtractRoot)
                    .where(criteriaBuilder.and(predicatesApDetails.toArray(new Predicate[]{})));
            Query query = em.createQuery(apDetailsExtractCriteriaQuery);
            String apDetailsQueryString = query.unwrap(org.hibernate.Query.class).getQueryString();
            org.hibernate.Query apDetailsQuery = openSession.createQuery(apDetailsQueryString);

            // Filtering AP AE Details
            apAeDetailsExtractCriteriaQuery.select(apAeDetailsExtractRoot)
                    .where(criteriaBuilder.and(predicatesApDetails.toArray(new Predicate[]{})));
            Query queryAe = em.createQuery(apAeDetailsExtractCriteriaQuery);
            String apAeDetailsQueryString = queryAe.unwrap(org.hibernate.Query.class).getQueryString();
            org.hibernate.Query apAeDetailsQuery = openSession.createQuery(apAeDetailsQueryString);

            // Filtering AP OR Details
            apOrDetailsExtractCriteriaQuery.select(apOrDetailsExtractRoot)
                    .where(criteriaBuilder.and(predicatesApDetails.toArray(new Predicate[]{})));
            Query queryOr = em.createQuery(apOrDetailsExtractCriteriaQuery);
            String apOrDetailsQueryString = queryOr.unwrap(org.hibernate.Query.class).getQueryString();
            org.hibernate.Query apOrDetailsQuery = openSession.createQuery(apOrDetailsQueryString);

            if (setUpdateDtTm) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.UPDATE_FROM_DATE,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.UPDATE_FROM_DATE));
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.UPDATE_TO_DATE,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.UPDATE_TO_DATE));
            }

            if (setProjId) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.PROJ_ID,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_ID));
                apAeDetailsQuery = apAeDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.PROJ_ID,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_ID));
                apOrDetailsQuery = apOrDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.PROJ_ID,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_ID));
            }
            if (setProjName) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.PROJ_NAME,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_NAME));
                apAeDetailsQuery = apAeDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.PROJ_NAME,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_NAME));
                apOrDetailsQuery = apOrDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.PROJ_NAME,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_NAME));
            }
            if (setProjStatus) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.PROJ_STATUS,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_STATUS));
                apAeDetailsQuery = apAeDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.PROJ_STATUS,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_STATUS));
                apOrDetailsQuery = apOrDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.PROJ_STATUS,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_STATUS));
            }
            if (setActivityType) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.ACTIVITY_TYPE,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.ACTIVITY_TYPE));
            }
            if (setNature) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.NATURE,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.NATURE));
            }
            if (setProjFunc) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.PROJ_FUNC,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.PROJ_FUNC));
            }
            if (setRptLoctn) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.RPT_LOCTN,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.RPT_LOCTN));
            }
            if (setFah) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.FAH,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.FAH));
            }
            if (setLah) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.LAH,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.LAH));
            }
            if (setManager) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.MANAGER,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.MANAGER));
            }
            if (setAgileFlg) {
                apDetailsQuery = apDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.AGILE_FLG,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.AGILE_FLG));
            }
            if (setAeId) {
                apAeDetailsQuery = apAeDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.AE_ID,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.AE_ID));
            }
            if (setAeName) {
                apAeDetailsQuery = apAeDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.AE_NAME,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.AE_NAME));
            }
            if (setAePriFunc) {
                apAeDetailsQuery = apAeDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.AE_PRI_FUNC,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.AE_PRI_FUNC));
            }
            if (setOrId) {
                apOrDetailsQuery = apOrDetailsQuery.setParameter(Const.AP_MIS_PARAMETERS.OR_ID,
                        parameterMap.get(Const.AP_MIS_PARAMETERS.OR_ID));
            }

            // Creating Workbook
            workBook = excelUtil.createWorkbook();
            genereateAuditProjectColHeaders(workBook, sheetNames, headerDesc);

            ScrollableResults scrollApResult = apDetailsQuery.setReadOnly(true).scroll(ScrollMode.FORWARD_ONLY);
            // int counter = 0;
            while (scrollApResult.next()) {
                /*if (++counter > 0 && counter % 100 == 0) {
                    LOGGER.finer("fetched " + counter + " entities");
                }*/
                ApDetailsExtract misEntity = (ApDetailsExtract) scrollApResult.get()[0];
                generateExcelFormatData(misEntity, workBook, columnMapping, sheetNames[0]);
            }
            scrollApResult.close();

            ScrollableResults scrollApAeResult = apAeDetailsQuery.setReadOnly(true).scroll(ScrollMode.FORWARD_ONLY);
            while (scrollApAeResult.next()) {
                ApAeDetailsExtract apAeEntity = (ApAeDetailsExtract) scrollApAeResult.get()[0];
                generateExcelFormatData(apAeEntity, workBook, columnMapping, sheetNames[1]);
            }
            scrollApAeResult.close();

            ScrollableResults scrollApOrResult = apOrDetailsQuery.setReadOnly(true).scroll(ScrollMode.FORWARD_ONLY);
            while (scrollApOrResult.next()) {
                ApOrDetailsExtract apOrEntity = (ApOrDetailsExtract) scrollApOrResult.get()[0];
                generateExcelFormatData(apOrEntity, workBook, columnMapping, sheetNames[2]);
            }
            scrollApOrResult.close();

            // resizeColumnAutoSize(workBook, sheetNames, columnMpng);
        } catch (Exception e) {
            LOGGER.info(e.getMessage());
            e.printStackTrace();
        } finally {
            LOGGER.info("Closed Stateless Session");
            openSession.close();
        }

        LOGGER.info("Prepared workbook");
        return workBook;
    }

    private Map<String, Map<String, Boolean>> generateFilterMapping(String[] sheetNames) {
        LOGGER.info("Inside generateFilterMapping()");
        Map<String, Map<String, Boolean>> filterMapping = new HashMap<>();
        for (String sheetName : sheetNames) {

        }
        return filterMapping;
    }

    private Map<String, List<Map<Integer, String>>> generateColumnMpngList(String[] sheetNames) throws ParseException {
        LOGGER.info("Inside generateColumnMpngList()");
        Map<String, List<Map<Integer, String>>> columnMpng = new HashMap<>();
        int count = 0;
        List<Map<Integer, String>> dataMapperList = null;
        for (String sheetNm : sheetNames) {
            dataMapperList = new ArrayList<>();
            String jsonString = env.getRequiredProperty(Const.MIS_EXPORT.AP_SHEETS_COL_HEADER_PREFIX + "sheet" + count);
            dataMapperList.add(AuditUtils.getRequiredValuesFromJson(jsonString, "columnName"));
            dataMapperList.add(AuditUtils.getRequiredValuesFromJson(jsonString, "dataType"));
            columnMpng.put(sheetNm, dataMapperList);
            count++;
        }
        LOGGER.info("Columns mapped");
        return columnMpng;
    }

    private String[] getSheetsDescription(String timeStamp, int sheetCount) {
        String[] headers = env.getRequiredProperty(Const.MIS_EXPORT.AP_MIS_REPORT_SHEET_HEADERS).split(",");
        String exportDate = " - Export Date : " + ((timeStamp == null) ? formatter.format(new Date()) : timeStamp);
        for (int i = 0; i < sheetCount; i++) {
            headers[i] = headers[i].concat(exportDate);
        }
        return headers;
    }

    private void genereateAuditProjectColHeaders(SXSSFWorkbook wb, String[] sheetNames, String[] headerDesc) throws ParseException {
        LOGGER.info("Inside genereateAuditProjectColHeaders()");
        int count = 0;
        for (String sheet : sheetNames) {
            String jsonString = env.getRequiredProperty(Const.MIS_EXPORT.AP_SHEETS_COL_HEADER_PREFIX + "sheet" + count);
            Map<Integer, String> columsList = AuditUtils.getRequiredValuesFromJson(jsonString, "columnDisplayName");
            if (headerDesc[count].length() > 1)
                excelUtil.createAuditProjHeader(wb, sheet, columsList, headerDesc[count]);
            else
                excelUtil.createAuditProjHeader(wb, sheet, columsList, null);
            count++;
        }
        LOGGER.info("Column headers created");
    }

    private void generateExcelFormatData(Object misObj, SXSSFWorkbook workBook, String sheetName,
                                         Map<String, List<Map<Integer, String>>> columnMpng) throws ParseException {
        // LOGGER.info("Inside generateExcelFormatData()");
        if (null == misObj)
            return;
        excelUtil.processDataByRow(workBook, columnMpng, AuditUtils.convertObjToJSON(misObj), sheetName);
    }

    @SuppressWarnings("unused")
    private void resizeColumnAutoSize(SXSSFWorkbook workBook, String[] sheetNames,
                                      Map<String, List<Map<Integer, String>>> columnMpng/*, Map<String, Map<Integer, Integer>> textSize*/) {
        LOGGER.info("Inside resizeColumnAutoSize()");
        for (String sheet : sheetNames) {
            List<Map<Integer, String>> list = columnMpng.get(sheet);
            int size = list.get(0).keySet().size();
//            Map<Integer, Integer> textMaxSize = textSize.get(sheet);
            excelUtil.autoResizeColumns(size, workBook.getSheet(sheet)/*, textMaxSize*/);
        }
    }

}