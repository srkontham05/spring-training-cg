package com.srk.auditriskapp.utils;

import com.srk.auditriskapp.constants.Const;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ARAExcelUtility {

    private static SimpleDateFormat assmtDateFormatter = new SimpleDateFormat(Const.ASSESSMENT_PERIOD_DATE_FORMAT);
    private static SimpleDateFormat formatter = new SimpleDateFormat(Const.MIS_EXPORT.REPORT_DATE_FORMAT);
    private static SimpleDateFormat onlyDateformatter = new SimpleDateFormat(Const.MIS_EXPORT.REPORT_ONLY_DATE_FORMAT);

    private static JSONParser parser = new JSONParser();

    /*
     * Create WorkBook
     */
    public SXSSFWorkbook createWorkbook() {
        SXSSFWorkbook wb = new SXSSFWorkbook(100); // keep 100 rows in memory, exceeding rows will be flushed to disk
        wb.setCompressTempFiles(true);
        return wb;
    }

    /**
     * @param columsList
     */
    public SXSSFWorkbook createHeader(SXSSFWorkbook wb, Map<Integer, String> columsList, String sheetName,
                                      String description) {
        Sheet sh = wb.createSheet(sheetName);
        int rownum = 0;
        if (null != description) {
            setDescription(wb, sh, description);
			/*setDescription(wb, sh, "B", 0, 1, 23, 37);
			setDescription(wb, sh, "Control Effectiveness (Fail, Poor, SAN, Satisfactory, Good)", 0, 1, 38, 52);*/
            rownum = 2;
        }
        CellStyle headerStle = getHeaderCellStyle(wb, IndexedColors.BLACK);
        XSSFFont font = (XSSFFont) wb.createFont();
        font.setColor(IndexedColors.WHITE.index);
        font.setFontHeight((double) 10);
        headerStle.setFont(font);

        Row row = sh.createRow(rownum);
        Set<Integer> colIndex = columsList.keySet();
        for (Integer cellNum : colIndex) {
            Cell cell = row.createCell(cellNum);
            cell.setCellValue(columsList.get(cellNum));
            cell.setCellStyle(headerStle);
        }

        return wb;
    }

    /**
     * The two headers with merge headings
     */
    public SXSSFWorkbook setDescription(SXSSFWorkbook wb, Sheet sheet, String sTimeStamp) {

        Row firstHeadg = sheet.createRow(0);
        firstHeadg.setHeight((short) 700);
        XSSFFont firstHeaderFont = (XSSFFont) wb.createFont();
        firstHeaderFont.setBold(true);
        firstHeaderFont.setColor(IndexedColors.WHITE.index);
        firstHeaderFont.setFontHeight((double) 14);

        XSSFCellStyle firstRowStyle = (XSSFCellStyle) getHeaderCellStyle(wb, IndexedColors.RED);
        firstRowStyle.setFont(firstHeaderFont);
        firstRowStyle.setAlignment(CellStyle.ALIGN_CENTER);

        /*
         * 20 19 Inherent Risk (Minor, Moderate, Major)
         * 35 34 Control Effectiveness (Fail, Poor, SAN, Satisfactory, Good)
         * 50 49 Net Risk Rating
         * 65 64 Net Risk Rating Colour
         * 80 79 Net Risk Rating Score
         * 95 94 Net Risk Rating Justification
         */

        getMergedCell(new CellRangeAddress(0, 0, 0, 18), sheet, firstHeadg, firstHeaderFont, firstRowStyle, 0, "");
        getMergedCell(new CellRangeAddress(0, 0, 19, 33), sheet, firstHeadg, firstHeaderFont, firstRowStyle, 19,
                "Inherent Risk (Minor, Moderate, Major)");
        getMergedCell(new CellRangeAddress(0, 0, 34, 48), sheet, firstHeadg, firstHeaderFont, firstRowStyle, 34,
                "Control Effectiveness (Fail, Poor, SAN, Satisfactory, Good)");
        getMergedCell(new CellRangeAddress(0, 0, 49, 63), sheet, firstHeadg, firstHeaderFont, firstRowStyle, 49,
                "Net Risk Rating");
        getMergedCell(new CellRangeAddress(0, 0, 64, 78), sheet, firstHeadg, firstHeaderFont, firstRowStyle, 64,
                "Net Risk Rating Colour");
        getMergedCell(new CellRangeAddress(0, 0, 79, 93), sheet, firstHeadg, firstHeaderFont, firstRowStyle, 79,
                "Net Risk Rating Score");
        getMergedCell(new CellRangeAddress(0, 0, 94, 108), sheet, firstHeadg, firstHeaderFont, firstRowStyle, 94,
                "Net Risk Rating Justification");
        getMergedCell(new CellRangeAddress(0, 0, 109, 112), sheet, firstHeadg, firstHeaderFont, firstRowStyle, 109,
                "Management Overlay");

        XSSFCellStyle secondRowStyle = (XSSFCellStyle) getHeaderCellStyle(wb, IndexedColors.RED);
        secondRowStyle.setFont(firstHeaderFont);
        secondRowStyle.setAlignment(CellStyle.ALIGN_LEFT);
        secondRowStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);

        Row secondHeadg = sheet.createRow(1);
        secondHeadg.setHeight((short) 700);
        getMergedCell(new CellRangeAddress(1, 1, 0, 18), sheet, secondHeadg, firstHeaderFont, secondRowStyle, 0,
                "Auditable Entities Details - Export Date : " + sTimeStamp);

        XSSFFont blackFont = (XSSFFont) wb.createFont();
        blackFont.setBold(true);
        blackFont.setColor(IndexedColors.BLACK.index);
        blackFont.setFontHeight((double) 9);

        XSSFCellStyle blackRowStyle = (XSSFCellStyle) getHeaderCellStyle(wb, IndexedColors.RED);
        blackRowStyle.setFont(blackFont);
        blackRowStyle.setAlignment(CellStyle.ALIGN_LEFT);
        blackRowStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);

        generateRiskNos(secondHeadg, 19, blackRowStyle);
        generateRiskNos(secondHeadg, 34, blackRowStyle);
        generateRiskNos(secondHeadg, 49, blackRowStyle);
        generateRiskNos(secondHeadg, 64, blackRowStyle);
        generateRiskNos(secondHeadg, 79, blackRowStyle);
        generateRiskNos(secondHeadg, 94, blackRowStyle);
        generateEmptyCells(secondHeadg, 109, 112, blackRowStyle);

        return wb;
    }

    /**
     * This method demonstrates how to Auto resize Excel column
     */
    public void autoResizeColumns(int listSize, Sheet sh) {
        for (int colIndex = 0; colIndex < listSize; colIndex++) {
            sh.autoSizeColumn(colIndex);
        }
    }

    /**
     * This method will return Style of Header Cell
     *
     * @return
     */
    public static CellStyle getHeaderCellStyle(SXSSFWorkbook wb, IndexedColors backGroundColor) {
        CellStyle style = wb.createCellStyle();
        style.setFillForegroundColor(backGroundColor.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setBorderBottom(CellStyle.BORDER_THIN);
        style.setBottomBorderColor(IndexedColors.WHITE.getIndex());
        style.setBorderLeft(CellStyle.BORDER_THIN);
        style.setLeftBorderColor(IndexedColors.WHITE.getIndex());
        style.setBorderRight(CellStyle.BORDER_THIN);
        style.setRightBorderColor(IndexedColors.WHITE.getIndex());
        style.setBorderTop(CellStyle.BORDER_THIN);
        style.setTopBorderColor(IndexedColors.WHITE.getIndex());
        style.setAlignment(CellStyle.ALIGN_LEFT);
        style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
        style.setWrapText(true);
        return style;
    }

    /**
     * This method will return Style of Description First Cell
     *
     * @return
     */
    public static CellStyle getDescFirstCellStyle(SXSSFWorkbook wb, IndexedColors backGroundColor) {
        CellStyle style = wb.createCellStyle();
        style.setFillForegroundColor(backGroundColor.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setBorderBottom(CellStyle.BORDER_THIN);
        style.setBottomBorderColor(IndexedColors.WHITE.getIndex());
        style.setBorderLeft(CellStyle.BORDER_THIN);
        style.setLeftBorderColor(IndexedColors.WHITE.getIndex());
        style.setBorderTop(CellStyle.BORDER_THIN);
        style.setTopBorderColor(IndexedColors.WHITE.getIndex());
        style.setAlignment(CellStyle.ALIGN_LEFT);
        style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
        // style.setWrapText(true);
        return style;
    }

    /**
     * This method will return Style of Description Mid Cell
     *
     * @return
     */
    public static CellStyle getDescMidCellStyle(SXSSFWorkbook wb, IndexedColors backGroundColor) {
        CellStyle style = wb.createCellStyle();
        style.setFillForegroundColor(backGroundColor.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setBorderBottom(CellStyle.BORDER_THIN);
        style.setBottomBorderColor(IndexedColors.WHITE.getIndex());
        style.setBorderTop(CellStyle.BORDER_THIN);
        style.setTopBorderColor(IndexedColors.WHITE.getIndex());
        style.setAlignment(CellStyle.ALIGN_LEFT);
        style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
        // style.setWrapText(true);
        return style;
    }

    /**
     * This method will return Style of Description Last Cell
     *
     * @return
     */
    public static CellStyle getDescLastCellStyle(SXSSFWorkbook wb, IndexedColors backGroundColor) {
        CellStyle style = wb.createCellStyle();
        style.setFillForegroundColor(backGroundColor.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setBorderBottom(CellStyle.BORDER_THIN);
        style.setBottomBorderColor(IndexedColors.WHITE.getIndex());
        style.setBorderRight(CellStyle.BORDER_THIN);
        style.setRightBorderColor(IndexedColors.WHITE.getIndex());
        style.setBorderTop(CellStyle.BORDER_THIN);
        style.setTopBorderColor(IndexedColors.WHITE.getIndex());
        style.setAlignment(CellStyle.ALIGN_LEFT);
        style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
        // style.setWrapText(true);
        return style;
    }

    /**
     * This method will return style for Normal Cell
     *
     * @return
     */
    public CellStyle getCellStyle(SXSSFWorkbook wb) {
        CellStyle style = wb.createCellStyle();
        style.setBorderBottom(CellStyle.BORDER_THIN);
        style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderLeft(CellStyle.BORDER_THIN);
        style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderRight(CellStyle.BORDER_THIN);
        style.setRightBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderTop(CellStyle.BORDER_THIN);
        style.setTopBorderColor(IndexedColors.BLACK.getIndex());
        style.setAlignment(CellStyle.ALIGN_LEFT);
        // style.setWrapText(true);
        return style;
    }

    /**
     * This method will return style for Normal Cell to set Color
     *
     * @return
     */
    public CellStyle getCellColorStyle(SXSSFWorkbook wb, CellStyle style, IndexedColors color) {
        if(style == null)
            style = wb.createCellStyle();
        style.setFillForegroundColor(color.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        XSSFFont cellFont = (XSSFFont) wb.createFont();
        if (!color.equals(IndexedColors.YELLOW))
            cellFont.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(cellFont);
        return style;
    }

    /**
     * Empty cells with a style from and to
     */
    private void generateEmptyCells(Row row1, int iColStart, int iColEnd, XSSFCellStyle firstRowStyle) {
        for (int i = iColStart - 1; i < iColEnd; i++) {
            Cell cell = row1.createCell(iColStart++);
            cell.setCellStyle(firstRowStyle);
        }
    }

    /**
     * Cells with risk count for given style from column number
     */
    private void generateRiskNos(Row row1, int iColStart, XSSFCellStyle firstRowStyle) {
        for (int i = 1; i < 16; i++) {
            Cell cell = row1.createCell(iColStart++);
            cell.setCellValue(i);
            cell.setCellStyle(firstRowStyle);
        }
    }

    public static Cell getMergedCell(CellRangeAddress cellRange, Sheet sheet, Row row, XSSFFont font,
                                     XSSFCellStyle cellStyle, int iCol, String sLabel) {
        // CellRangeAddress address2 = new CellRangeAddress(fromRowNo, toRowNo, fromCol, toCol);
        sheet.addMergedRegion(cellRange);
        XSSFRichTextString rt2 = new XSSFRichTextString(sLabel);
        rt2.applyFont(font);
        Cell cell = row.createCell(iCol);
        cell.setCellStyle(cellStyle);
        cell.setCellValue(rt2);
        return cell;
    }

    /*	public void processDataByRow(SXSSFWorkbook wb, String sheetName, String jsonStringObj, int rowNo)
                throws ParseException {
            Row row = wb.getSheet(sheetName).createRow(rowNo);
            JSONObject jsonObj = (JSONObject) parser.parse(jsonStringObj);
            Iterator<?> jsonIterator = jsonObj.keySet().iterator();
            int cellCount = 0;
            Cell cell = null;
            while (jsonIterator.hasNext()) {
                cell = row.createCell(cellCount);
                String key = (String) jsonIterator.next();
                cell.setCellValue(String.valueOf(jsonObj.get(key)));
                cellCount++;
            }
        }
    */
/*
    public void processDataByRow(SXSSFWorkbook wb, String jsonStringObj, String sheetName,
                                 Map<String, List<Map<Integer, String>>> columnMpng) throws ParseException {
        Sheet sheet = wb.getSheet(sheetName);
        int rowNo = sheet.getLastRowNum();
        Row row = sheet.createRow(++rowNo);
        JSONObject jsonObj = (JSONObject) parser.parse(jsonStringObj);
        List<Map<Integer, String>> colMpngList = columnMpng.get(sheetName);
        for (Integer index : colMpngList.get(0).keySet()) {
            Cell cell = row.createCell(index);
            if (null != jsonObj.get(colMpngList.get(0).get(index))) {
                String value = String.valueOf(jsonObj.get(colMpngList.get(0).get(index)));
                String dataType = colMpngList.get(1).get(index);
                if (dataType.equalsIgnoreCase("date") && isLongType(value)) {
                    Date assmtDate = new Date(Long.parseLong(value));
                    value = assmtDateFormatter.format(assmtDate);
                }
                cell.setCellValue(value);
            }
        }
    }
*/


    public void processDataByRow(SXSSFWorkbook workBook, Map<String, List<Map<Integer, String>>> columnMpng,
                                 String jsonStringObj, String[] sheetNames) throws ParseException {
        for (String sheetName : sheetNames) {
            processSheetDataByRow(workBook, columnMpng, jsonStringObj, sheetName);
        }
    }

    public void processDataByRow(SXSSFWorkbook workBook, Map<String, List<Map<Integer, String>>> columnMpng,
                                 String jsonStringObj, String sheetName) throws ParseException {
        processSheetDataByRow(workBook, columnMpng, jsonStringObj, sheetName);
    }

    private void processSheetDataByRow(SXSSFWorkbook workBook, Map<String, List<Map<Integer, String>>> columnMpng, String jsonStringObj, String sheetName) throws ParseException {
        Sheet sheet = workBook.getSheet(sheetName);
        int rowNo = sheet.getLastRowNum();
        Row row = sheet.createRow(++rowNo);
        JSONObject jsonObj = (JSONObject) parser.parse(jsonStringObj);
        List<Map<Integer, String>> colMpngList = columnMpng.get(sheetName);
        for (Integer index : colMpngList.get(0).keySet()) {

            Cell cell = null;
            String value = String.valueOf(jsonObj.get(colMpngList.get(0).get(index)));
            String dataType = colMpngList.get(1).get(index);
            if (null == jsonObj.get(colMpngList.get(0).get(index)))
                cell = row.createCell(index, Cell.CELL_TYPE_BLANK);
            else if (dataType.equalsIgnoreCase("integer") || dataType.equalsIgnoreCase("bigdecimal"))
                cell = row.createCell(index, Cell.CELL_TYPE_NUMERIC);
            else
                cell = row.createCell(index);

            XSSFCellStyle cellStyle = null;
            cellStyle = (XSSFCellStyle) getCellStyle(workBook);
            cell.setCellStyle(cellStyle);

            if (null != jsonObj.get(colMpngList.get(0).get(index))) {
                if (colMpngList.get(0).get(index).endsWith(Const.AP_MIS_PARAMETERS.FLAG)) {
                    if (value.equals(Const.AP_MIS_PARAMETERS.YES_SYMBOL))
                        value = Const.AP_MIS_PARAMETERS.YES_VALUE;
                    if (value.equals(Const.AP_MIS_PARAMETERS.NO_SYMBOL))
                        value = Const.AP_MIS_PARAMETERS.NO_VALUE;
                }
                if (colMpngList.get(0).get(index).equals(Const.AP_MIS_PARAMETERS.CREATE_DT_TM)
                        || colMpngList.get(0).get(index).equals(Const.AP_MIS_PARAMETERS.UPDATE_DT_TM)) {
                    if (dataType.equalsIgnoreCase("date") && isLongType(value)) {
                        Date date = new Date(Long.parseLong(value));
                        value = formatter.format(date);
                    }
                }
                if (dataType.equalsIgnoreCase("date") && isLongType(value)) {
                    Date date = new Date(Long.parseLong(value));
                    value = onlyDateformatter.format(date);
                }
                if (dataType.equalsIgnoreCase("Integer"))
                    cell.setCellValue(Integer.parseInt(value));
                else if (dataType.equalsIgnoreCase("BigDecimal"))
                    cell.setCellValue((new BigDecimal((String) value)).doubleValue());
                else
                    cell.setCellValue(value);

                // Set Cell Color
                if (colMpngList.get(0).get(index).equals(Const.AP_MIS_PARAMETERS.AE_RISK_CLR) ||
                        colMpngList.get(0).get(index).equals(Const.AP_MIS_PARAMETERS.AE_FINAL_CLR)) {
                    switch (value.toUpperCase()) {
                        case "AMBER":
                            cell.setCellStyle(getCellColorStyle(workBook, cellStyle, IndexedColors.ORANGE));
                            break;
                        case "GREEN":
                            cell.setCellStyle(getCellColorStyle(workBook, cellStyle, IndexedColors.GREEN));
                            break;
                        case "GREY":
                            cell.setCellStyle(getCellColorStyle(workBook, cellStyle, IndexedColors.GREY_25_PERCENT));
                            break;
                        case "RED":
                            cell.setCellStyle(getCellColorStyle(workBook, cellStyle, IndexedColors.RED));
                            break;
                        case "YELLOW":
                            cell.setCellStyle(getCellColorStyle(workBook, cellStyle, IndexedColors.YELLOW));
                            break;
                    }
                }
            }
        }
    }

    private boolean isLongType(String value) {
        try {
            Long.parseLong(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * @param columsList
     */
    public SXSSFWorkbook createAuditProjHeader(SXSSFWorkbook wb, String sheetName, Map<Integer, String> columsList,
                                               String description) {
        SXSSFSheet sh = (SXSSFSheet) wb.createSheet(sheetName);
        sh.setRandomAccessWindowSize(100);// keep 100 rows in memory, exceeding rows will be flushed to disk

        Row row = sh.createRow(1);
        row.setHeight((short) 700);
        CellStyle headerStyle = getHeaderCellStyle(wb, IndexedColors.BLACK);
        XSSFFont font = (XSSFFont) wb.createFont();
        font.setBold(true);
        font.setFontHeight((double) 10);
        font.setColor(IndexedColors.WHITE.getIndex());
        headerStyle.setFont(font);

        Set<Integer> colIndex = columsList.keySet();
        for (Integer cellNum : colIndex) {
            Cell cell = row.createCell(cellNum);
            cell.setCellValue(columsList.get(cellNum));
            cell.setCellStyle(headerStyle);
        }
        sh.createFreezePane(0, 2);
        autoResizeColumns(columsList.size(), sh);

        if (null != description)
            setAuditProjDescription(wb, sh, description, 0, 0, columsList.size() - 1);

        return wb;
    }

    public SXSSFWorkbook setAuditProjDescription(SXSSFWorkbook wb, Sheet sheet, String description, int toRowNo,
                                                 int fromColCount, int toColCount) {
        Row row = sheet.createRow(0);
        row.setHeight((short) 700);
        // CellRangeAddress address = new CellRangeAddress(0, toRowNo, fromColCount,
        // toColCount);
        // sheet.addMergedRegion(address);
        XSSFFont font1 = (XSSFFont) wb.createFont();
        font1.setBold(true);
        font1.setFontHeight((double) 14);
        font1.setColor(IndexedColors.WHITE.getIndex());

        // First Cell
        XSSFCellStyle first = (XSSFCellStyle) getDescFirstCellStyle(wb, IndexedColors.RED);
        first.setFont(font1);
        first.setAlignment(CellStyle.ALIGN_LEFT);

        // XSSFRichTextString rt2 = new XSSFRichTextString(description);
        // rt2.applyFont(font1);
        Cell cell = row.createCell(0);
        cell.setCellStyle(first);
        cell.setCellValue(description);

        // Mid Cells
        for (int col = fromColCount + 1; col < toColCount; col++) {
            XSSFCellStyle midStyle = (XSSFCellStyle) getDescMidCellStyle(wb, IndexedColors.RED);
            Cell mid = row.createCell(col);
            mid.setCellStyle(midStyle);
            // mid.setCellValue("");
        }
        // Last Cell
        XSSFCellStyle lastStyle = (XSSFCellStyle) getDescLastCellStyle(wb, IndexedColors.RED);
        Cell last = row.createCell(toColCount);
        last.setCellStyle(lastStyle);
        // last.setCellValue("");

        return wb;
    }

}
