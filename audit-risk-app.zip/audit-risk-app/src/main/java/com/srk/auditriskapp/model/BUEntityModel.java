package com.srk.auditriskapp.model;

public class BUEntityModel {
    Integer entityNum;
    Integer buNum;

    public Integer getEntityNum() {
        return entityNum;
    }

    public void setEntityNum(Integer entityNum) {
        this.entityNum = entityNum;
    }

    public Integer getBuNum() {
        return buNum;
    }

    public void setBuNum(Integer buNum) {
        this.buNum = buNum;
    }
}
