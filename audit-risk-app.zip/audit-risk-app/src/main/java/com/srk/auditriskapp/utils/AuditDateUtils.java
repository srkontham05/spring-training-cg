package com.srk.auditriskapp.utils;

import java.util.Date;

public class AuditDateUtils {

    public static Date convertUTCToSGT(String fromAssmtPeriod) {
        return null;
    }
}
