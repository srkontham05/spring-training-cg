package com.srk.auditriskapp.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * The persistent class for the ap_ae_details_extract database table.
 */
@Entity
@Table(name = "ap_ae_details_extract")
@NamedQuery(name = "ApAeDetailsExtract.findAll", query = "SELECT a FROM ApAeDetailsExtract a")
public class ApAeDetailsExtract implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ROW_NUM")
    private Integer rowNum;

    @Column(name = "AE_ID")
    private String aeId;

    @Column(name = "AE_MAN_HRS")
    private Integer aeManHrs;

    @Column(name = "AE_NM")
    private String aeNm;

    @Column(name = "AE_RISK_CLR")
    private String aeRiskClr;

    @Column(name = "AE_STS")
    private String aeSts;

    @Column(name = "AUDIT_PROJ_ID")
    private String auditProjId;

    @Column(name = "AUDIT_PROJ_NM")
    private String auditProjNm;

    @Column(name = "AUDIT_PROJ_NUM")
    private Integer auditProjNum;

    @Column(name = "AE_PRI_FUNC")
    private String aePriFunc;

    @Column(name = "AE_LOCTN")
    private String aeLoctn;

    @Column(name = "ENTITY_NM")
    private String entityNm;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_AUDIT_DT")
    private Date lastAuditDt;

    @Column(name = "OVERLAY_CLR")
    private String overlayClr;

    @Column(name = "PROJ_STS")
    private String projSts;

    @Column(name = "REVISED_AE_MAN_HOUR")
    private Integer revisedAeManHour;

    public ApAeDetailsExtract() {
    }

    public Integer getRowNum() {
        return rowNum;
    }

    public void setRowNum(Integer rowNum) {
        this.rowNum = rowNum;
    }

    public String getAeId() {
        return aeId;
    }

    public void setAeId(String aeId) {
        this.aeId = aeId;
    }

    public Integer getAeManHrs() {
        return aeManHrs;
    }

    public void setAeManHrs(Integer aeManHrs) {
        this.aeManHrs = aeManHrs;
    }

    public String getAeNm() {
        return aeNm;
    }

    public void setAeNm(String aeNm) {
        this.aeNm = aeNm;
    }

    public String getAeRiskClr() {
        return aeRiskClr;
    }

    public void setAeRiskClr(String aeRiskClr) {
        this.aeRiskClr = aeRiskClr;
    }

    public String getAeSts() {
        return aeSts;
    }

    public void setAeSts(String aeSts) {
        this.aeSts = aeSts;
    }

    public String getAuditProjId() {
        return auditProjId;
    }

    public void setAuditProjId(String auditProjId) {
        this.auditProjId = auditProjId;
    }

    public String getAuditProjNm() {
        return auditProjNm;
    }

    public void setAuditProjNm(String auditProjNm) {
        this.auditProjNm = auditProjNm;
    }

    public Integer getAuditProjNum() {
        return auditProjNum;
    }

    public void setAuditProjNum(Integer auditProjNum) {
        this.auditProjNum = auditProjNum;
    }

    public String getAePriFunc() {
        return aePriFunc;
    }

    public void setAePriFunc(String aePriFunc) {
        this.aePriFunc = aePriFunc;
    }

    public String getAeLoctn() {
        return aeLoctn;
    }

    public void setAeLoctn(String aeLoctn) {
        this.aeLoctn = aeLoctn;
    }

    public String getEntityNm() {
        return entityNm;
    }

    public void setEntityNm(String entityNm) {
        this.entityNm = entityNm;
    }

    public Date getLastAuditDt() {
        return lastAuditDt;
    }

    public void setLastAuditDt(Date lastAuditDt) {
        this.lastAuditDt = lastAuditDt;
    }

    public String getOverlayClr() {
        return overlayClr;
    }

    public void setOverlayClr(String overlayClr) {
        this.overlayClr = overlayClr;
    }

    public String getProjSts() {
        return projSts;
    }

    public void setProjSts(String projSts) {
        this.projSts = projSts;
    }

    public Integer getRevisedAeManHour() {
        return revisedAeManHour;
    }

    public void setRevisedAeManHour(Integer revisedAeManHour) {
        this.revisedAeManHour = revisedAeManHour;
    }

}