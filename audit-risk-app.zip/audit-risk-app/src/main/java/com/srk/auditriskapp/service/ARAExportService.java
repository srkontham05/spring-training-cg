package com.srk.auditriskapp.service;

import com.srk.auditriskapp.model.AEExportRequestModel;
import com.srk.auditriskapp.model.APExportRequestModel;
import com.srk.auditriskapp.model.HeaderModel;
import org.json.simple.parser.ParseException;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public interface ARAExportService {

    public HttpServletResponse aeExport(HttpServletResponse response, AEExportRequestModel exportModel,
                                        HeaderModel header) throws ParseException, IOException;

    public HttpServletResponse apExport(HttpServletResponse response, APExportRequestModel exportModel,
                                        HeaderModel header) throws ParseException, IOException;

}
