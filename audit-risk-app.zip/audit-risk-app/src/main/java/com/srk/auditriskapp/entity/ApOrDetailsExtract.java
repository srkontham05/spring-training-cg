package com.srk.auditriskapp.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
 * The persistent class for the ap_or_details_extract database table.
 */
@Entity
@Table(name = "ap_or_details_extract")
@NamedQuery(name = "ApOrDetailsExtract.findAll", query = "SELECT a FROM ApOrDetailsExtract a")
public class ApOrDetailsExtract implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ROW_NUM")
    private Integer rowNum;

    @Column(name = "ACT_MATERIAL_FLG")
    private String actMaterialFlg;

    @Column(name = "AUDIT_PROJ_ID")
    private String auditProjId;

    @Column(name = "AUDIT_PROJ_NM")
    private String auditProjNm;

    @Column(name = "AUDIT_PROJ_NUM")
    private Integer auditProjNum;

    @Column(name = "MAS634_FLG")
    private String mas634Flg;

    @Column(name = "OR_ID")
    private String orId;

    @Column(name = "OR_NM")
    private String orNm;

    @Column(name = "OTSRCNG_TYP_CD")
    private String otsrcngTypCd;

    @Column(name = "PROJ_STS")
    private String projSts;

    @Column(name = "SDM_NM")
    private String sdmNm;

    @Column(name = "SRVC_NM")
    private String srvcNm;

    public ApOrDetailsExtract() {
    }

    public String getActMaterialFlg() {
        return this.actMaterialFlg;
    }

    public void setActMaterialFlg(String actMaterialFlg) {
        this.actMaterialFlg = actMaterialFlg;
    }

    public String getAuditProjId() {
        return this.auditProjId;
    }

    public void setAuditProjId(String auditProjId) {
        this.auditProjId = auditProjId;
    }

    public String getAuditProjNm() {
        return this.auditProjNm;
    }

    public void setAuditProjNm(String auditProjNm) {
        this.auditProjNm = auditProjNm;
    }

    public Integer getAuditProjNum() {
        return this.auditProjNum;
    }

    public void setAuditProjNum(Integer auditProjNum) {
        this.auditProjNum = auditProjNum;
    }

    public String getMas634Flg() {
        return this.mas634Flg;
    }

    public void setMas634Flg(String mas634Flg) {
        this.mas634Flg = mas634Flg;
    }

    public String getOrId() {
        return this.orId;
    }

    public void setOrId(String orId) {
        this.orId = orId;
    }

    public String getOrNm() {
        return this.orNm;
    }

    public void setOrNm(String orNm) {
        this.orNm = orNm;
    }

    public String getOtsrcngTypCd() {
        return this.otsrcngTypCd;
    }

    public void setOtsrcngTypCd(String otsrcngTypCd) {
        this.otsrcngTypCd = otsrcngTypCd;
    }

    public String getProjSts() {
        return this.projSts;
    }

    public void setProjSts(String projSts) {
        this.projSts = projSts;
    }

    public Integer getRowNum() {
        return this.rowNum;
    }

    public void setRowNum(Integer rowNum) {
        this.rowNum = rowNum;
    }

    public String getSdmNm() {
        return this.sdmNm;
    }

    public void setSdmNm(String sdmNm) {
        this.sdmNm = sdmNm;
    }

    public String getSrvcNm() {
        return this.srvcNm;
    }

    public void setSrvcNm(String srvcNm) {
        this.srvcNm = srvcNm;
    }

}