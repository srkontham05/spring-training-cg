package com.srk.auditriskapp.constants;

public interface Const {

    String REQ_RES_DATE_FORMAT = "dd-MMM-yyyy";
    String ASSESSMENT_PERIOD_DATE_FORMAT = "MMM-yyyy";

    interface COLOR {
        String AMBER = "AMBER";
        String GREEN = "GREEN";
        String GREY = "GREY";
        String RED = "RED";
        String YELLOW = "YELLOW";
    }
    interface MIS_PARAMETERS {
        String ASSMT_FROM_DATE = "fromAssmtPeriod";
        String ASSMT_TO_DATE = "toAssmtPeriod";
        String UPDATE_FROM_DATE = "fromUpdatedDate";
        String UPDATE_TO_DATE = "toUpdatedDate";
        String ENTITY = "entity";
        String FUNCTION = "orgUnit";
        String MANAGER = "manager";
        String UNIT = "function";
        String STATUS = "status";

        String VIEW_COLUMN_ASM_DT = "assmntDt";
        String VIEW_COLUMN_UPD_DT = "updateDtTm";
        String VIEW_COLUMN_ENTITY = "entity";
        String VIEW_COLUMN_FUNCTION = "buNm";
        String VIEW_COLUMN_MANAGER = "auditMngr";
        String VIEW_COLUMN_UNIT = "unit";
        String VIEW_COLUMN_STATUS = "statusDesc";
    }

    interface MIS_EXPORT {
        String REPORT_DESC_DATE_FORMAT = "MM/dd/yyyy HH:mm:ss aaa";
        String REPORT_DATE_FORMAT = "dd-MMM-yyyy HH:mm:ss";
        String REPORT_ONLY_DATE_FORMAT = "dd-MMM-yyyy";

        String MIS_SHEET_NAMES = "auditrisk.ae.mis.report.sheet.name";
        String SHEET_COL_HEADER_PREFIX = "auditrisk.ae.mis.report.json.";

        String AP_MIS_REPORT_FILE_NAME = "auditrisk.ap.mis.report.name";
        String AP_MIS_REPORT_SHEET_NAMES = "auditrisk.ap.mis.report.sheet.names";
        String AP_MIS_REPORT_SHEET_HEADERS = "auditrisk.ap.mis.report.sheet.headers";
        String AP_SHEETS_COL_HEADER_PREFIX = "auditrisk.ap.mis.report.json.";
    }

    interface AP_MIS_PARAMETERS {
        String UPDATE_FROM_DATE = "fromUpdatedDate";
        String UPDATE_TO_DATE = "toUpdatedDate";

        String CREATE_DT_TM = "createDtTm";
        String UPDATE_DT_TM = "updateDtTm";
        String PROJ_ID = "auditProjId";
        String PROJ_NAME = "auditProjNm";
        String PROJ_STATUS = "projSts";
        String ACTIVITY_TYPE = "activityTypDesc";
        String NATURE = "natureDesc";
        String PROJ_FUNC = "projFunc";
        String RPT_LOCTN = "rptLoctn";
        String FAH = "fahNm";
        String LAH = "lahNm";
        String MANAGER = "mngrNm";
        String AGILE_FLG = "agileFlg";
        String AE_ID = "aeId";
        String AE_NAME = "aeNm";
        String AE_PRI_FUNC = "aePriFunc";
        String OR_ID = "orId";

        String FLAG = "Flg";
        String YES_SYMBOL = "Y";
        String YES_VALUE = "Yes";
        String NO_SYMBOL = "N";
        String NO_VALUE = "No";

        String AE_RISK_CLR = "aeRiskClr";
        String AE_FINAL_CLR = "overlayClr";
    }
}
