package com.srk.auditriskapp.model;

public class AEExportRequestModel {

    private String fromAssmtPeriod;
    private String toAssmtPeriod;
    private String fromUpdatedDate;
    private String toUpdatedDate;
    private String entity;
    private String orgUnit;
    private String function;
    private String status;
    private String manager;
    private String timestamp;

    public String getFromAssmtPeriod() {
        return fromAssmtPeriod;
    }

    public void setFromAssmtPeriod(String fromAssmtPeriod) {
        this.fromAssmtPeriod = fromAssmtPeriod;
    }

    public String getToAssmtPeriod() {
        return toAssmtPeriod;
    }

    public void setToAssmtPeriod(String toAssmtPeriod) {
        this.toAssmtPeriod = toAssmtPeriod;
    }

    public String getFromUpdatedDate() {
        return fromUpdatedDate;
    }

    public void setFromUpdatedDate(String fromUpdatedDate) {
        this.fromUpdatedDate = fromUpdatedDate;
    }

    public String getToUpdatedDate() {
        return toUpdatedDate;
    }

    public void setToUpdatedDate(String toUpdatedDate) {
        this.toUpdatedDate = toUpdatedDate;
    }

    public String getEntity() {
        return entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }

    public String getOrgUnit() {
        return orgUnit;
    }

    public void setOrgUnit(String orgUnit) {
        this.orgUnit = orgUnit;
    }

    public String getFunction() {
        return function;
    }

    public void setFunction(String function) {
        this.function = function;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

}
