package com.srk.auditriskapp.repository;

import java.util.List;

public interface IOtsrcngRgstrRepository {
    List<Integer> getORKeysSubContractForMainContract(Integer integer);

    List<Object[]> fetchOSPforSubContract(List<Integer> orKeysSubContracts);
}
