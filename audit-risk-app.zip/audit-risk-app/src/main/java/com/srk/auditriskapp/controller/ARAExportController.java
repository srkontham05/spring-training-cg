package com.srk.auditriskapp.controller;

import com.srk.auditriskapp.model.AEExportRequestModel;
import com.srk.auditriskapp.model.APExportRequestModel;
import com.srk.auditriskapp.model.HeaderModel;
import com.srk.auditriskapp.model.Request;
import com.srk.auditriskapp.service.ARAExportService;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@CrossOrigin
@RestController
@RequestMapping("/mis")
public class ARAExportController {

    @Autowired
    private ARAExportService araExportService;

    @PostMapping(value = "/aeExport")
    public void aeExport(@RequestBody Request<AEExportRequestModel> request, HttpServletResponse response)
            throws ParseException, IOException {
        HeaderModel header = request.getHeader();
        response = araExportService.aeExport(response, request.getPayload(), header);
        response.flushBuffer();
    }

    @PostMapping(value = "/apExport")
    public void apExport(@RequestBody Request<APExportRequestModel> request, HttpServletResponse response)
            throws ParseException, IOException {
        HeaderModel header = request.getHeader();
        response = araExportService.apExport(response, request.getPayload(), header);
        response.flushBuffer();
    }

}
